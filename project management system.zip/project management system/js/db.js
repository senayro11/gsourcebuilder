// ============================================================
// db.js – localStorage-based "file" database
// Simulates txt/JSON file storage; GitHub Pages compatible
// ============================================================

const DB_KEY = 'protrack_db_v1';

const DB = {
  _data: null,

  _defaults() {
    return {
      users: [
        { id: 'u1', username: 'admin', password: 'admin123', name: 'Admin User', role: 'admin', email: 'admin@protrack.com', department: 'Management', phone: '', createdAt: '2024-01-01', active: true },
        { id: 'u2', username: 'user', password: 'user123', name: 'Juan dela Cruz', role: 'user', email: 'juan@protrack.com', department: 'Engineering', phone: '', createdAt: '2024-01-15', active: true },
        { id: 'u3', username: 'guest', password: 'guest', name: 'Guest Viewer', role: 'guest', email: 'guest@protrack.com', department: '', phone: '', createdAt: '2024-02-01', active: true }
      ],
      projects: [
        { id: 'p1', name: 'Website Redesign', code: 'WR-001', description: 'Complete overhaul of company website with modern UI/UX', status: 'in-progress', priority: 'high', startDate: '2024-03-01', endDate: '2024-06-30', budget: 250000, spent: 120000, progress: 48, manager: 'u1', team: ['u1','u2'], client: 'Internal', category: 'IT', tags: ['web','design'], createdAt: '2024-03-01' },
        { id: 'p2', name: 'Mobile App Development', code: 'MA-002', description: 'Cross-platform mobile app for iOS and Android', status: 'in-progress', priority: 'high', startDate: '2024-02-15', endDate: '2024-08-31', budget: 500000, spent: 280000, progress: 56, manager: 'u2', team: ['u2'], client: 'ABC Corp', category: 'IT', tags: ['mobile','app'], createdAt: '2024-02-15' },
        { id: 'p3', name: 'Office Renovation', code: 'OR-003', description: 'Renovation of 3rd floor office space', status: 'not-started', priority: 'medium', startDate: '2024-07-01', endDate: '2024-09-30', budget: 800000, spent: 0, progress: 0, manager: 'u1', team: ['u1'], client: 'Internal', category: 'Facilities', tags: ['renovation'], createdAt: '2024-04-01' },
        { id: 'p4', name: 'ERP Implementation', code: 'ERP-004', description: 'Full enterprise resource planning system rollout', status: 'on-hold', priority: 'high', startDate: '2024-01-10', endDate: '2024-12-31', budget: 1500000, spent: 450000, progress: 30, manager: 'u1', team: ['u1','u2'], client: 'Internal', category: 'IT', tags: ['erp','system'], createdAt: '2024-01-10' },
        { id: 'p5', name: 'Brand Identity Update', code: 'BI-005', description: 'New logo, color palette, and brand guidelines', status: 'completed', priority: 'low', startDate: '2024-01-05', endDate: '2024-03-31', budget: 80000, spent: 75000, progress: 100, manager: 'u2', team: ['u2'], client: 'Internal', category: 'Marketing', tags: ['branding'], createdAt: '2024-01-05' }
      ],
      tasks: [
        { id: 't1', projectId: 'p1', title: 'Design wireframes', description: 'Create lo-fi and hi-fi wireframes', status: 'done', priority: 'high', assignee: 'u2', dueDate: '2024-03-20', createdAt: '2024-03-01', completedAt: '2024-03-19' },
        { id: 't2', projectId: 'p1', title: 'Frontend development', description: 'Build React components', status: 'in-progress', priority: 'high', assignee: 'u2', dueDate: '2024-05-15', createdAt: '2024-03-21', completedAt: null },
        { id: 't3', projectId: 'p1', title: 'Backend API integration', description: 'Connect frontend to REST APIs', status: 'todo', priority: 'medium', assignee: 'u1', dueDate: '2024-06-01', createdAt: '2024-03-21', completedAt: null },
        { id: 't4', projectId: 'p2', title: 'UI/UX Design', description: 'Design app screens', status: 'done', priority: 'high', assignee: 'u2', dueDate: '2024-03-10', createdAt: '2024-02-15', completedAt: '2024-03-08' },
        { id: 't5', projectId: 'p2', title: 'Core feature development', description: 'Build main app features', status: 'in-progress', priority: 'high', assignee: 'u2', dueDate: '2024-07-01', createdAt: '2024-03-11', completedAt: null },
        { id: 't6', projectId: 'p4', title: 'Requirements gathering', description: 'Document business requirements', status: 'done', priority: 'high', assignee: 'u1', dueDate: '2024-02-01', createdAt: '2024-01-10', completedAt: '2024-01-30' },
        { id: 't7', projectId: 'p4', title: 'Vendor selection', description: 'Evaluate and select ERP vendor', status: 'done', priority: 'high', assignee: 'u1', dueDate: '2024-03-01', createdAt: '2024-02-01', completedAt: '2024-02-28' },
        { id: 't8', projectId: 'p4', title: 'Module configuration', description: 'Configure core ERP modules', status: 'in-progress', priority: 'high', assignee: 'u2', dueDate: '2024-08-01', createdAt: '2024-03-01', completedAt: null }
      ],
      milestones: [
        { id: 'm1', projectId: 'p1', title: 'Design Phase Complete', dueDate: '2024-03-31', status: 'completed', description: 'All design assets approved' },
        { id: 'm2', projectId: 'p1', title: 'Beta Launch', dueDate: '2024-05-31', status: 'upcoming', description: 'Internal beta testing' },
        { id: 'm3', projectId: 'p1', title: 'Go Live', dueDate: '2024-06-30', status: 'upcoming', description: 'Public launch' },
        { id: 'm4', projectId: 'p2', title: 'MVP Release', dueDate: '2024-05-01', status: 'upcoming', description: 'Minimum viable product' },
        { id: 'm5', projectId: 'p4', title: 'Pilot Go-Live', dueDate: '2024-09-01', status: 'upcoming', description: '1 department pilot' }
      ],
      costs: [
        { id: 'c1', projectId: 'p1', category: 'Labor', description: 'Developer salaries', amount: 90000, date: '2024-03-31', type: 'actual' },
        { id: 'c2', projectId: 'p1', category: 'Software', description: 'Design tools & licenses', amount: 15000, date: '2024-03-01', type: 'actual' },
        { id: 'c3', projectId: 'p1', category: 'Miscellaneous', description: 'Travel & meetings', amount: 15000, date: '2024-04-15', type: 'actual' },
        { id: 'c4', projectId: 'p2', category: 'Labor', description: 'Dev team salaries', amount: 240000, date: '2024-04-30', type: 'actual' },
        { id: 'c5', projectId: 'p2', category: 'Infrastructure', description: 'Cloud hosting & CI/CD', amount: 40000, date: '2024-03-01', type: 'actual' },
        { id: 'c6', projectId: 'p4', category: 'Software', description: 'ERP license fee', amount: 350000, date: '2024-02-01', type: 'actual' },
        { id: 'c7', projectId: 'p4', category: 'Consulting', description: 'Implementation partner', amount: 100000, date: '2024-03-15', type: 'actual' },
        { id: 'c8', projectId: 'p5', category: 'Design', description: 'Branding agency fee', amount: 75000, date: '2024-02-15', type: 'actual' }
      ],
      team: [
        { id: 'tm1', name: 'Admin User', role: 'Project Manager', department: 'Management', email: 'admin@protrack.com', skills: ['Management','Planning','Budgeting'], userId: 'u1', avatar: 'A' },
        { id: 'tm2', name: 'Juan dela Cruz', role: 'Full Stack Developer', department: 'Engineering', email: 'juan@protrack.com', skills: ['React','Node.js','Python'], userId: 'u2', avatar: 'J' },
        { id: 'tm3', name: 'Maria Santos', role: 'UI/UX Designer', department: 'Design', email: 'maria@protrack.com', skills: ['Figma','CSS','User Research'], userId: null, avatar: 'M' },
        { id: 'tm4', name: 'Pedro Reyes', role: 'DevOps Engineer', department: 'Engineering', email: 'pedro@protrack.com', skills: ['Docker','AWS','CI/CD'], userId: null, avatar: 'P' }
      ],
      notifications: [],
      settings: { companyName: 'ProTrack Corp', currency: 'PHP', dateFormat: 'YYYY-MM-DD', fiscalYear: 'January' },
      session: null
    };
  },

  load() {
    try {
      const raw = localStorage.getItem(DB_KEY);
      this._data = raw ? JSON.parse(raw) : this._defaults();
      // Ensure all collections exist
      const defaults = this._defaults();
      for (const key of Object.keys(defaults)) {
        if (this._data[key] === undefined) this._data[key] = defaults[key];
      }
    } catch (e) {
      this._data = this._defaults();
    }
    return this;
  },

  save() {
    try {
      localStorage.setItem(DB_KEY, JSON.stringify(this._data));
    } catch (e) {
      console.error('DB save failed', e);
    }
    return this;
  },

  exportTxt() {
    const blob = new Blob([JSON.stringify(this._data, null, 2)], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `protrack_backup_${new Date().toISOString().slice(0,10)}.txt`;
    a.click();
  },

  importTxt(text) {
    try {
      const imported = JSON.parse(text);
      this._data = { ...this._defaults(), ...imported };
      this.save();
      return true;
    } catch { return false; }
  },

  reset() { this._data = this._defaults(); this.save(); },

  // ── CRUD helpers ──
  getAll(col) { return [...(this._data[col] || [])]; },
  getById(col, id) { return (this._data[col] || []).find(r => r.id === id); },
  insert(col, record) {
    if (!this._data[col]) this._data[col] = [];
    record.id = record.id || this._genId();
    this._data[col].push(record);
    this.save();
    return record;
  },
  update(col, id, changes) {
    const idx = (this._data[col] || []).findIndex(r => r.id === id);
    if (idx === -1) return false;
    this._data[col][idx] = { ...this._data[col][idx], ...changes };
    this.save();
    return this._data[col][idx];
  },
  delete(col, id) {
    const before = (this._data[col] || []).length;
    this._data[col] = (this._data[col] || []).filter(r => r.id !== id);
    this.save();
    return (this._data[col] || []).length < before;
  },
  where(col, fn) { return (this._data[col] || []).filter(fn); },
  _genId() { return '_' + Math.random().toString(36).slice(2, 11); },

  // ── Settings ──
  getSetting(key) { return (this._data.settings || {})[key]; },
  setSetting(key, val) { if (!this._data.settings) this._data.settings = {}; this._data.settings[key] = val; this.save(); },

  // ── Notifications ──
  addNotif(msg, type = 'info') {
    const n = { id: this._genId(), msg, type, at: new Date().toISOString(), read: false };
    this._data.notifications.unshift(n);
    if (this._data.notifications.length > 50) this._data.notifications = this._data.notifications.slice(0,50);
    this.save();
    return n;
  },
  clearNotifs() { this._data.notifications = []; this.save(); }
};

DB.load();
