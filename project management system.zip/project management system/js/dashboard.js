// ============================================================
// dashboard.js
// ============================================================

function renderDashboard(area) {
  const projects = DB.getAll('projects');
  const tasks = DB.getAll('tasks');
  const costs = DB.getAll('costs');

  const totalBudget = projects.reduce((s, p) => s + (p.budget || 0), 0);
  const totalSpent = projects.reduce((s, p) => s + (p.spent || 0), 0);
  const inProgress = projects.filter(p => p.status === 'in-progress').length;
  const completed = projects.filter(p => p.status === 'completed').length;
  const onHold = projects.filter(p => p.status === 'on-hold').length;
  const overdue = projects.filter(p => p.endDate && new Date(p.endDate) < new Date() && p.status !== 'completed').length;
  const pendingTasks = tasks.filter(t => t.status !== 'done').length;

  const statuses = ['not-started','in-progress','on-hold','completed','delayed'];
  const statusColors = ['#94A3B8','#3B82F6','#F59E0B','#10B981','#EF4444'];
  const statusCounts = statuses.map(s => projects.filter(p => p.status === s).length);

  const totalDonutCirc = 2 * Math.PI * 40;
  function donutSlices() {
    const total = projects.length || 1;
    let offset = 0;
    return statusCounts.map((cnt, i) => {
      const pct = cnt / total;
      const len = pct * totalDonutCirc;
      const slice = `<circle cx="50" cy="50" r="40" fill="none" stroke="${statusColors[i]}" stroke-width="16"
        stroke-dasharray="${len} ${totalDonutCirc - len}" stroke-dashoffset="${-offset}" transform="rotate(-90 50 50)" />`;
      offset += len;
      return slice;
    }).join('');
  }

  // Recent projects
  const recent = [...projects].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);

  // Budget by category
  const categories = [...new Set(projects.map(p => p.category))];
  const catBudgets = categories.map(c => ({
    c, budget: projects.filter(p => p.category === c).reduce((s, p) => s + p.budget, 0)
  }));
  const maxCat = Math.max(...catBudgets.map(x => x.budget), 1);

  area.innerHTML = `
  <div class="page">
    <div class="page-header">
      <div>
        <div class="page-title">Dashboard</div>
        <div class="page-subtitle">Welcome back, ${Auth.currentUser?.name || 'User'} · ${new Date().toLocaleDateString('en-PH', {weekday:'long',year:'numeric',month:'long',day:'numeric'})}</div>
      </div>
      ${Auth.can('write') ? `<div class="btn-group"><button class="btn-primary" onclick="navigate('projects')">+ New Project</button><button class="btn-secondary" onclick="DB.exportTxt();toast('Backup exported!','success')">⬇ Backup</button></div>` : ''}
    </div>

    <!-- STATS -->
    <div class="stats-grid">
      <div class="stat-card blue">
        <div class="stat-icon">📁</div>
        <div class="stat-info">
          <div class="stat-value">${projects.length}</div>
          <div class="stat-label">Total Projects</div>
        </div>
      </div>
      <div class="stat-card green">
        <div class="stat-icon">▶</div>
        <div class="stat-info">
          <div class="stat-value">${inProgress}</div>
          <div class="stat-label">In Progress</div>
        </div>
      </div>
      <div class="stat-card yellow">
        <div class="stat-icon">✓</div>
        <div class="stat-info">
          <div class="stat-value">${completed}</div>
          <div class="stat-label">Completed</div>
        </div>
      </div>
      <div class="stat-card red">
        <div class="stat-icon">⚠</div>
        <div class="stat-info">
          <div class="stat-value">${overdue}</div>
          <div class="stat-label">Overdue</div>
        </div>
      </div>
      <div class="stat-card purple">
        <div class="stat-icon">₱</div>
        <div class="stat-info">
          <div class="stat-value">${(totalBudget/1000000).toFixed(1)}M</div>
          <div class="stat-label">Total Budget</div>
        </div>
      </div>
      <div class="stat-card blue">
        <div class="stat-icon">📋</div>
        <div class="stat-info">
          <div class="stat-value">${pendingTasks}</div>
          <div class="stat-label">Open Tasks</div>
        </div>
      </div>
    </div>

    <div class="grid-2" style="gap:1rem;margin-bottom:1rem">
      <!-- STATUS DONUT -->
      <div class="card">
        <div class="card-header"><div class="card-title">Project Status Overview</div></div>
        <div class="donut-wrap">
          <svg width="120" height="120" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="40" fill="none" stroke="var(--border)" stroke-width="16"/>
            ${donutSlices()}
            <text x="50" y="55" text-anchor="middle" font-size="14" font-weight="700" fill="var(--text)">${projects.length}</text>
            <text x="50" y="66" text-anchor="middle" font-size="7" fill="var(--text-muted)">Projects</text>
          </svg>
          <div class="donut-legend">
            ${statuses.map((s, i) => statusCounts[i] > 0 ? `
              <div class="donut-legend-item">
                <div class="donut-dot" style="background:${statusColors[i]}"></div>
                <span style="flex:1">${s.replace(/-/g,' ').replace(/\b\w/g,c=>c.toUpperCase())}</span>
                <strong>${statusCounts[i]}</strong>
              </div>` : '').join('')}
          </div>
        </div>
      </div>

      <!-- BUDGET OVERVIEW -->
      <div class="card">
        <div class="card-header"><div class="card-title">Budget Utilization</div></div>
        <div style="margin-bottom:1rem">
          <div style="display:flex;justify-content:space-between;font-size:.82rem;margin-bottom:.4rem">
            <span class="text-muted">Total Spent</span>
            <strong>${fmtCurrency(totalSpent)}</strong>
          </div>
          <div class="progress-bar" style="height:10px">
            <div class="progress-fill ${totalSpent/totalBudget > .9 ? 'fill-red' : totalSpent/totalBudget > .7 ? 'fill-yellow' : 'fill-blue'}" style="width:${Math.min(100,(totalSpent/totalBudget*100)||0).toFixed(1)}%"></div>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:.75rem;color:var(--text-muted);margin-top:.3rem">
            <span>${((totalSpent/totalBudget)||0).toFixed(1)*100}% used</span>
            <span>Budget: ${fmtCurrency(totalBudget)}</span>
          </div>
        </div>
        <div style="border-top:1px solid var(--border);padding-top:.85rem">
          <div style="font-size:.8rem;font-weight:600;margin-bottom:.6rem;color:var(--text-muted)">BY CATEGORY</div>
          ${catBudgets.map(x => `
            <div style="margin-bottom:.5rem">
              <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:.2rem">
                <span>${x.c}</span><span class="text-muted">${fmtCurrency(x.budget)}</span>
              </div>
              <div class="progress-bar" style="height:5px">
                <div class="progress-fill fill-blue" style="width:${(x.budget/maxCat*100).toFixed(1)}%"></div>
              </div>
            </div>`).join('')}
        </div>
      </div>
    </div>

    <!-- RECENT PROJECTS TABLE -->
    <div class="card" style="margin-bottom:1rem">
      <div class="card-header">
        <div class="card-title">Recent Projects</div>
        <button class="btn-ghost btn-sm" onclick="navigate('projects')">View All →</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Project</th><th>Status</th><th>Progress</th><th>Budget</th><th>Due Date</th><th>Priority</th></tr></thead>
          <tbody>
            ${recent.map(p => `
              <tr onclick="navigate('tracker');setTimeout(()=>openProjectDetail('${p.id}'),100)" style="cursor:pointer">
                <td>
                  <div style="font-weight:600;font-size:.875rem">${p.name}</div>
                  <div style="font-size:.75rem;color:var(--text-muted)">${p.code}</div>
                </td>
                <td>${statusBadge(p.status)}</td>
                <td style="min-width:120px">${progressBar(p.progress || 0)}</td>
                <td>
                  <div>${fmtCurrency(p.spent)}</div>
                  <div style="font-size:.72rem;color:var(--text-muted)">of ${fmtCurrency(p.budget)}</div>
                </td>
                <td style="white-space:nowrap">
                  <div>${fmtDate(p.endDate)}</div>
                  ${daysLeft(p.endDate) !== null ? `<div style="font-size:.72rem;color:${daysLeft(p.endDate)<0?'var(--danger)':daysLeft(p.endDate)<14?'var(--warning)':'var(--text-muted)'}">${daysLeft(p.endDate)<0?`${Math.abs(daysLeft(p.endDate))}d overdue`:`${daysLeft(p.endDate)}d left`}</div>` : ''}
                </td>
                <td>${priorityBadge(p.priority)}</td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- RECENT TASKS + UPCOMING MILESTONES -->
    <div class="grid-2" style="gap:1rem">
      <div class="card">
        <div class="card-header">
          <div class="card-title">Recent Tasks</div>
          <button class="btn-ghost btn-sm" onclick="navigate('tasks')">View Board →</button>
        </div>
        ${tasks.slice(0,5).map(t => `
          <div style="display:flex;align-items:center;gap:.75rem;padding:.5rem 0;border-bottom:1px solid var(--border)">
            <div style="width:8px;height:8px;border-radius:50%;background:${t.priority==='high'?'var(--danger)':t.priority==='medium'?'var(--warning)':'var(--success)'};flex-shrink:0"></div>
            <div style="flex:1;font-size:.85rem">
              <div style="font-weight:500;${t.status==='done'?'text-decoration:line-through;opacity:.5':''}">${t.title}</div>
              <div style="font-size:.72rem;color:var(--text-muted)">${projectName(t.projectId)}</div>
            </div>
            ${statusBadge(t.status === 'done' ? 'completed' : t.status === 'in-progress' ? 'in-progress' : 'not-started')}
          </div>`).join('')}
      </div>
      <div class="card">
        <div class="card-header">
          <div class="card-title">Upcoming Milestones</div>
          <button class="btn-ghost btn-sm" onclick="navigate('milestones')">View All →</button>
        </div>
        ${DB.getAll('milestones').filter(m=>m.status!=='completed').slice(0,5).map(m => `
          <div style="display:flex;align-items:center;gap:.75rem;padding:.5rem 0;border-bottom:1px solid var(--border)">
            <div style="font-size:1.1rem">◆</div>
            <div style="flex:1;font-size:.85rem">
              <div style="font-weight:600">${m.title}</div>
              <div style="font-size:.72rem;color:var(--text-muted)">${projectName(m.projectId)}</div>
            </div>
            <div style="font-size:.75rem;white-space:nowrap;color:${daysLeft(m.dueDate)<7?'var(--danger)':'var(--text-muted)'}">${fmtDate(m.dueDate)}</div>
          </div>`).join('') || '<div class="text-muted text-center mt-2">No upcoming milestones</div>'}
      </div>
    </div>
  </div>`;
}
