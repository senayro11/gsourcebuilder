// ============================================================
// team.js
// ============================================================

function renderTeam(area) {
  area.innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Team Members</div>
        <div class="page-subtitle">Manage project team</div></div>
      ${Auth.can('write')?`<button class="btn-primary" onclick="openTeamForm()">+ Add Member</button>`:''}
    </div>
    <div class="filter-bar">
      <input id="tSearch" type="text" placeholder="Search members..." oninput="filterTeam()" />
      <select id="tDept" onchange="filterTeam()">
        <option value="">All Departments</option>
        ${[...new Set(DB.getAll('team').map(t=>t.department))].map(d=>`<option>${d}</option>`).join('')}
      </select>
    </div>
    <div id="teamContent"></div>
  </div>`;
  filterTeam();
}

function filterTeam() {
  const q = (document.getElementById('tSearch')?.value||'').toLowerCase();
  const dept = document.getElementById('tDept')?.value||'';
  const members = DB.getAll('team').filter(m=>
    (!q||m.name.toLowerCase().includes(q)||(m.role||'').toLowerCase().includes(q))&&
    (!dept||m.department===dept)
  );
  const content = document.getElementById('teamContent');
  if (!members.length) {
    content.innerHTML = `<div class="empty-state"><div class="empty-icon">👥</div><p>No members found</p></div>`;
    return;
  }
  content.innerHTML = `<div class="grid-auto">${members.map(memberCard).join('')}</div>`;
}

function memberCard(m) {
  const projects = DB.getAll('projects').filter(p => (p.team||[]).includes(m.userId)||p.manager===m.userId);
  return `
  <div class="card">
    <div style="display:flex;align-items:center;gap:.85rem;margin-bottom:.85rem">
      <div class="avatar" style="width:48px;height:48px;font-size:1.1rem">${m.avatar||m.name.charAt(0)}</div>
      <div>
        <div style="font-weight:700;font-size:.95rem">${m.name}</div>
        <div style="font-size:.8rem;color:var(--text-muted)">${m.role}</div>
        <div style="font-size:.75rem;color:var(--text-muted)">${m.department}</div>
      </div>
    </div>
    <div style="font-size:.8rem;margin-bottom:.75rem">
      <div style="margin-bottom:.25rem">📧 ${m.email||'–'}</div>
    </div>
    ${m.skills?.length?`<div style="display:flex;flex-wrap:wrap;gap:.3rem;margin-bottom:.75rem">
      ${m.skills.map(s=>`<span class="badge badge-blue">${s}</span>`).join('')}
    </div>`:''}
    <div style="font-size:.78rem;color:var(--text-muted);margin-bottom:.6rem">
      Assigned to ${projects.length} project(s)
    </div>
    ${Auth.can('write')?`<div class="btn-group">
      <button class="btn-sm btn-secondary" onclick="openTeamForm('${m.id}')">Edit</button>
      ${Auth.isAdmin()?`<button class="btn-sm btn-danger" onclick="deleteTeamMember('${m.id}')">Remove</button>`:''}
    </div>`:''}
  </div>`;
}

function openTeamForm(id) {
  if (!Auth.can('write')) { toast('No permission','error'); return; }
  const m = id ? DB.getById('team',id) : {};
  const users = DB.getAll('users').filter(u=>u.role!=='guest');
  openModal(id?'Edit Member':'Add Team Member', `
    <div class="form-row">
      <div class="form-group"><label>Full Name *</label><input id="tmName" value="${m.name||''}" /></div>
      <div class="form-group"><label>Avatar Initial</label><input id="tmAvatar" value="${m.avatar||''}" maxlength="2" placeholder="A" /></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Role / Title</label><input id="tmRole" value="${m.role||''}" /></div>
      <div class="form-group"><label>Department</label><input id="tmDept" value="${m.department||''}" /></div>
    </div>
    <div class="form-group"><label>Email</label><input type="email" id="tmEmail" value="${m.email||''}" /></div>
    <div class="form-group"><label>Skills (comma-separated)</label><input id="tmSkills" value="${(m.skills||[]).join(', ')}" /></div>
    <div class="form-group"><label>Link to System User (optional)</label><select id="tmUserId">
      <option value="">None</option>
      ${users.map(u=>`<option value="${u.id}" ${m.userId===u.id?'selected':''}>${u.name||u.username}</option>`).join('')}
    </select></div>
    <div class="modal-footer">
      <button class="btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveTeamMember('${id||''}')">Save</button>
    </div>
  `);
}

function saveTeamMember(id) {
  const name = document.getElementById('tmName').value.trim();
  if (!name) { toast('Name required','error'); return; }
  const skills = document.getElementById('tmSkills').value.split(',').map(s=>s.trim()).filter(Boolean);
  const data = {
    name, skills,
    avatar: document.getElementById('tmAvatar').value || name.charAt(0),
    role: document.getElementById('tmRole').value,
    department: document.getElementById('tmDept').value,
    email: document.getElementById('tmEmail').value,
    userId: document.getElementById('tmUserId').value||null
  };
  if (id) { DB.update('team',id,data); toast('Updated!','success'); }
  else { DB.insert('team',data); toast('Member added!','success'); }
  closeModal(); navigate('team');
}

function deleteTeamMember(id) {
  if (!confirm('Remove this team member?')) return;
  DB.delete('team',id);
  toast('Removed','success');
  navigate('team');
}
