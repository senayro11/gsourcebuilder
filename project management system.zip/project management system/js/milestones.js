// ============================================================
// milestones.js
// ============================================================

function renderMilestones(area) {
  area.innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Milestones</div>
        <div class="page-subtitle">Track key project milestones</div></div>
      ${Auth.can('write')?`<button class="btn-primary" onclick="openMilestoneForm()">+ Add Milestone</button>`:''}
    </div>
    <div class="filter-bar">
      <select id="mProject" onchange="filterMilestones()">
        <option value="">All Projects</option>
        ${DB.getAll('projects').map(p=>`<option value="${p.id}">${p.name}</option>`).join('')}
      </select>
      <select id="mStatus" onchange="filterMilestones()">
        <option value="">All Status</option>
        <option>upcoming</option><option>completed</option><option>delayed</option>
      </select>
    </div>
    <div id="milestonesContent"></div>
  </div>`;
  filterMilestones();
}

function filterMilestones() {
  const pid = document.getElementById('mProject')?.value||'';
  const st = document.getElementById('mStatus')?.value||'';
  const milestones = DB.getAll('milestones').filter(m=>
    (!pid||m.projectId===pid)&&(!st||m.status===st)
  ).sort((a,b)=>new Date(a.dueDate)-new Date(b.dueDate));

  const content = document.getElementById('milestonesContent');
  if (!milestones.length) {
    content.innerHTML = `<div class="empty-state"><div class="empty-icon">◆</div><p>No milestones found</p></div>`;
    return;
  }

  content.innerHTML = `
    <div class="grid-auto">
      ${milestones.map(m => {
        const dl = daysLeft(m.dueDate);
        const overdue = dl !== null && dl < 0 && m.status !== 'completed';
        const nearDue = dl !== null && dl <= 7 && dl >= 0 && m.status !== 'completed';
        const badgeClass = m.status==='completed'?'badge-green':overdue?'badge-red':nearDue?'badge-yellow':'badge-blue';
        return `<div class="card" style="border-left:4px solid ${m.status==='completed'?'var(--success)':overdue?'var(--danger)':nearDue?'var(--warning)':'var(--accent)'}">
          <div style="display:flex;justify-content:space-between;margin-bottom:.5rem">
            <span class="badge ${badgeClass}">${m.status}</span>
            <div class="table-actions">
              ${Auth.can('write')?`<button class="btn-sm btn-secondary" onclick="openMilestoneForm('${m.id}')">Edit</button>`:''}
              ${Auth.isAdmin()?`<button class="btn-sm btn-danger" onclick="deleteMilestone('${m.id}')">Del</button>`:''}
            </div>
          </div>
          <div style="font-weight:700;font-size:.95rem;margin-bottom:.3rem">◆ ${m.title}</div>
          <div style="font-size:.8rem;color:var(--text-muted);margin-bottom:.6rem">${projectName(m.projectId)}</div>
          ${m.description?`<div style="font-size:.82rem;margin-bottom:.6rem">${m.description}</div>`:''}
          <div style="display:flex;justify-content:space-between;align-items:center;font-size:.78rem">
            <span>📅 ${fmtDate(m.dueDate)}</span>
            <span style="color:${overdue?'var(--danger)':nearDue?'var(--warning)':'var(--text-muted)'}">
              ${m.status==='completed'?'✓ Done':overdue?`${Math.abs(dl)}d overdue`:dl===0?'Due today':`${dl}d left`}
            </span>
          </div>
          ${Auth.can('write')&&m.status!=='completed'?`
          <div style="margin-top:.75rem">
            <button class="btn-sm btn-primary full-width" onclick="completeMilestone('${m.id}')">Mark Complete</button>
          </div>`:''}
        </div>`;
      }).join('')}
    </div>`;
}

function openMilestoneForm(id) {
  if (!Auth.can('write')) { toast('No permission','error'); return; }
  const m = id ? DB.getById('milestones',id) : {};
  const projects = DB.getAll('projects');
  openModal(id?'Edit Milestone':'New Milestone', `
    <div class="form-group"><label>Project *</label><select id="mProjId">
      ${projects.map(p=>`<option value="${p.id}" ${m.projectId===p.id?'selected':''}>${p.name}</option>`).join('')}
    </select></div>
    <div class="form-group"><label>Milestone Title *</label><input id="mTitle" value="${m.title||''}" /></div>
    <div class="form-group"><label>Description</label><textarea id="mDesc">${m.description||''}</textarea></div>
    <div class="form-row">
      <div class="form-group"><label>Due Date *</label><input type="date" id="mDue" value="${m.dueDate||''}" /></div>
      <div class="form-group"><label>Status</label><select id="mSt">
        ${['upcoming','completed','delayed'].map(s=>`<option ${m.status===s?'selected':''}>${s}</option>`).join('')}
      </select></div>
    </div>
    <div class="modal-footer">
      <button class="btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveMilestone('${id||''}')">Save</button>
    </div>
  `);
}

function saveMilestone(id) {
  const title = document.getElementById('mTitle').value.trim();
  const dueDate = document.getElementById('mDue').value;
  if (!title||!dueDate) { toast('Title and due date required','error'); return; }
  const data = {
    projectId: document.getElementById('mProjId').value,
    title, dueDate,
    description: document.getElementById('mDesc').value,
    status: document.getElementById('mSt').value
  };
  if (id) { DB.update('milestones',id,data); toast('Updated!','success'); }
  else { DB.insert('milestones',data); toast('Milestone added!','success'); }
  closeModal(); navigate('milestones');
}

function completeMilestone(id) {
  DB.update('milestones',id,{status:'completed'});
  toast('Milestone completed! 🎉','success');
  navigate('milestones');
}

function deleteMilestone(id) {
  if (!confirm('Delete this milestone?')) return;
  DB.delete('milestones',id);
  toast('Deleted','success');
  navigate('milestones');
}
