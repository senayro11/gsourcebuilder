// ============================================================
// gantt.js – Interactive Gantt Chart
// ============================================================

function renderGantt(area) {
  const projects = DB.getAll('projects');
  area.innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Gantt Chart</div>
        <div class="page-subtitle">Visual project timeline</div></div>
      <div class="btn-group">
        <select id="ganttProject" onchange="buildGantt()" style="min-width:180px">
          <option value="">All Projects</option>
          ${projects.map(p=>`<option value="${p.id}">${p.name}</option>`).join('')}
        </select>
        <select id="ganttView" onchange="buildGantt()">
          <option value="month">Monthly</option>
          <option value="quarter">Quarterly</option>
        </select>
      </div>
    </div>
    <div class="card">
      <div class="gantt-wrapper" id="ganttWrapper"></div>
    </div>
    <div id="ganttLegend" style="display:flex;gap:.75rem;flex-wrap:wrap;margin-top:.75rem;font-size:.78rem">
      ${[['not-started','#94A3B8'],['in-progress','#3B82F6'],['completed','#10B981'],['on-hold','#F59E0B'],['delayed','#EF4444']].map(([s,c])=>
        `<div style="display:flex;align-items:center;gap:.35rem"><div style="width:14px;height:14px;border-radius:3px;background:${c}"></div>${s.replace(/-/g,' ')}</div>`
      ).join('')}
      <div style="display:flex;align-items:center;gap:.35rem"><div style="width:14px;height:14px;border-radius:3px;background:var(--danger);opacity:.8"></div>Today</div>
    </div>
  </div>`;
  buildGantt();
}

function buildGantt() {
  const wrapper = document.getElementById('ganttWrapper');
  if (!wrapper) return;
  const pid = document.getElementById('ganttProject')?.value || '';
  const viewMode = document.getElementById('ganttView')?.value || 'month';
  let projects = pid ? [DB.getById('projects', pid)].filter(Boolean) : DB.getAll('projects');
  projects = projects.filter(p => p.startDate && p.endDate);

  if (!projects.length) {
    wrapper.innerHTML = `<div class="empty-state"><div class="empty-icon">📅</div><p>No projects with date ranges to display</p></div>`;
    return;
  }

  // Compute date range
  const allStarts = projects.map(p => new Date(p.startDate));
  const allEnds = projects.map(p => new Date(p.endDate));
  let rangeStart = new Date(Math.min(...allStarts));
  let rangeEnd = new Date(Math.max(...allEnds));
  // Pad by 1 month each side
  rangeStart = new Date(rangeStart.getFullYear(), rangeStart.getMonth() - 1, 1);
  rangeEnd = new Date(rangeEnd.getFullYear(), rangeEnd.getMonth() + 2, 0);

  // Build month columns
  const months = [];
  let cur = new Date(rangeStart.getFullYear(), rangeStart.getMonth(), 1);
  while (cur <= rangeEnd) {
    months.push(new Date(cur));
    cur = new Date(cur.getFullYear(), cur.getMonth() + 1, 1);
  }

  const COL_W = viewMode === 'quarter' ? 60 : 120; // px per month
  const totalW = months.length * COL_W;

  function dayOffset(date) {
    const d = new Date(date);
    const diffMs = d - rangeStart;
    const totalMs = rangeEnd - rangeStart;
    return (diffMs / totalMs) * totalW;
  }
  function dayWidth(start, end) {
    const s = new Date(start < rangeStart ? rangeStart : start);
    const e = new Date(end > rangeEnd ? rangeEnd : end);
    const diffMs = e - s;
    const totalMs = rangeEnd - rangeStart;
    return Math.max(8, (diffMs / totalMs) * totalW);
  }

  const todayOffset = dayOffset(new Date());

  // Build tasks for task-level detail
  const tasksByProject = {};
  projects.forEach(p => {
    tasksByProject[p.id] = DB.where('tasks', t => t.projectId === p.id && t.dueDate);
  });

  // Build rows (projects + tasks under each)
  const rows = [];
  projects.forEach(p => {
    rows.push({ type: 'project', data: p });
    if (pid) { // Only show task rows for single project view
      tasksByProject[p.id].forEach(t => rows.push({ type: 'task', data: t, projectId: p.id }));
    }
  });

  const statusColor = {'not-started':'not-started','in-progress':'in-progress','completed':'completed','on-hold':'on-hold','delayed':'delayed'};

  wrapper.innerHTML = `
    <div class="gantt-container" style="min-width:${200+totalW}px">
      <!-- LEFT LABELS -->
      <div class="gantt-labels">
        <div class="gantt-label-header">Project / Task</div>
        ${rows.map(r => {
          if (r.type === 'project') {
            return `<div class="gantt-label-row" onclick="openProjectDetail('${r.data.id}')" title="${r.data.name}">
              <span class="label-icon">◈</span>
              <div style="overflow:hidden">
                <div style="font-weight:700;font-size:.82rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${r.data.name}</div>
                <div style="font-size:.68rem;color:var(--text-muted)">${r.data.code}</div>
              </div>
            </div>`;
          } else {
            return `<div class="gantt-label-row" style="padding-left:1.5rem;background:rgba(241,245,249,.5)" title="${r.data.title}">
              <span class="label-icon" style="font-size:.6rem">✓</span>
              <div style="font-size:.75rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${r.data.title}</div>
            </div>`;
          }
        }).join('')}
      </div>

      <!-- CHART AREA -->
      <div class="gantt-chart-area">
        <!-- Month headers -->
        <div class="gantt-header-months">
          ${months.map(m => `<div class="gantt-month" style="width:${COL_W}px;min-width:${COL_W}px">
            ${m.toLocaleDateString('en-PH',{month:'short',year:'2-digit'})}
          </div>`).join('')}
        </div>

        <!-- Rows -->
        <div class="gantt-rows" style="width:${totalW}px;position:relative">
          <!-- Today line -->
          ${todayOffset >= 0 && todayOffset <= totalW ? `
            <div class="gantt-today-line" style="left:${todayOffset}px">
              <div class="gantt-today-label">Today</div>
            </div>` : ''}

          ${rows.map(r => {
            const isProject = r.type === 'project';
            const p = isProject ? r.data : null;
            const t = isProject ? null : r.data;
            const start = isProject ? p.startDate : (t.dueDate ? new Date(new Date(t.dueDate).getTime() - 7*86400000).toISOString().slice(0,10) : null);
            const end = isProject ? p.endDate : t.dueDate;
            if (!start || !end) return `<div class="gantt-row" style="width:${totalW}px">
              <div class="gantt-grid-lines">${months.map(()=>`<div class="gantt-grid-line" style="width:${COL_W}px"></div>`).join('')}</div>
            </div>`;

            const left = dayOffset(start);
            const width = dayWidth(start, end);
            const label = isProject ? `${p.name} (${p.progress||0}%)` : t.title;
            const cls = isProject ? statusColor[p.status] || 'not-started' : (t.status==='done'?'completed':t.status==='in-progress'?'in-progress':'not-started');
            const h = isProject ? '22px' : '14px';
            const top = isProject ? '11px' : '15px';

            return `<div class="gantt-row" style="width:${totalW}px">
              <div class="gantt-grid-lines">${months.map(()=>`<div class="gantt-grid-line" style="width:${COL_W}px"></div>`).join('')}</div>
              <div class="gantt-bar ${cls}" style="left:${Math.max(0,left)}px;width:${width}px;height:${h};top:${top};font-size:${isProject?'.72rem':'.65rem'}"
                title="${label}&#10;${fmtDate(start)} → ${fmtDate(end)}" onclick="${isProject?`openProjectDetail('${p.id}')`:''}" >
                ${isProject ? `<div class="bar-progress" style="width:${p.progress||0}%"></div>` : ''}
                <span style="position:relative;z-index:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${label}</span>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>`;
}
