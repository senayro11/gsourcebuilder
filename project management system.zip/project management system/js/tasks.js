// ============================================================
// tasks.js – Kanban Task Board
// ============================================================

function renderTasks(area) {
  area.innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Task Board</div>
        <div class="page-subtitle">Manage tasks across projects</div></div>
      ${Auth.can('write')?`<button class="btn-primary" onclick="openTaskForm()">+ New Task</button>`:''}
    </div>
    <div class="filter-bar">
      <select id="tProject" onchange="renderTaskBoard()">
        <option value="">All Projects</option>
        ${DB.getAll('projects').map(p=>`<option value="${p.id}">${p.name}</option>`).join('')}
      </select>
      <select id="tPriority" onchange="renderTaskBoard()">
        <option value="">All Priority</option>
        <option>high</option><option>medium</option><option>low</option>
      </select>
      <select id="tAssignee" onchange="renderTaskBoard()">
        <option value="">All Assignees</option>
        ${DB.getAll('users').filter(u=>u.role!=='guest').map(u=>`<option value="${u.id}">${u.name||u.username}</option>`).join('')}
      </select>
    </div>
    <div class="kanban-board" id="taskBoard"></div>
  </div>`;
  renderTaskBoard();
}

function renderTaskBoard() {
  const pid = document.getElementById('tProject')?.value||'';
  const pri = document.getElementById('tPriority')?.value||'';
  const uid = document.getElementById('tAssignee')?.value||'';

  let tasks = DB.getAll('tasks').filter(t=>
    (!pid||t.projectId===pid)&&
    (!pri||t.priority===pri)&&
    (!uid||t.assignee===uid)
  );

  const cols = [
    {id:'todo',label:'To Do',color:'#94A3B8'},
    {id:'in-progress',label:'In Progress',color:'#3B82F6'},
    {id:'review',label:'Review',color:'#8B5CF6'},
    {id:'done',label:'Done',color:'#10B981'}
  ];

  const board = document.getElementById('taskBoard');
  board.innerHTML = cols.map(col => {
    const colTasks = tasks.filter(t=>t.status===col.id);
    return `
    <div class="kanban-col">
      <div class="kanban-col-header">
        <span style="display:flex;align-items:center;gap:.4rem">
          <span style="width:10px;height:10px;border-radius:50%;background:${col.color};display:inline-block"></span>
          ${col.label}
        </span>
        <span class="badge badge-gray">${colTasks.length}</span>
      </div>
      <div id="col-${col.id}">
        ${colTasks.map(t => taskCard(t, col.id)).join('')}
      </div>
      ${Auth.can('write')?`<button class="btn-ghost btn-sm" style="width:100%;margin-top:.5rem" onclick="openTaskForm('','${col.id}')">+ Add task</button>`:''}
    </div>`;
  }).join('');
}

function taskCard(t, colId) {
  const priColors = {high:'var(--danger)',medium:'var(--warning)',low:'var(--success)'};
  const overdue = t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'done';
  return `
  <div class="task-card ${t.priority}" onclick="openTaskDetail('${t.id}')">
    <div class="task-title">${t.title}</div>
    <div style="font-size:.75rem;color:var(--text-muted);margin-bottom:.4rem">${projectName(t.projectId)}</div>
    ${t.description?`<div style="font-size:.78rem;color:var(--text-muted);margin-bottom:.4rem;line-height:1.3">${t.description.slice(0,80)}${t.description.length>80?'...':''}</div>`:''}
    <div class="task-meta">
      <span style="color:${priColors[t.priority]||'var(--text-muted)'}">● ${t.priority||'–'}</span>
      <span style="color:${overdue?'var(--danger)':'var(--text-muted)'}">${t.dueDate?fmtDate(t.dueDate):'No due date'}</span>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:.4rem">
      <div style="font-size:.72rem;color:var(--text-muted)">${userName(t.assignee)||'Unassigned'}</div>
      ${Auth.can('write')?`<div class="table-actions" onclick="event.stopPropagation()">
        ${colId!=='done'?`<button class="btn-sm btn-secondary" onclick="advanceTask('${t.id}')">→</button>`:''}
        <button class="btn-sm btn-secondary" onclick="openTaskForm('${t.id}')">Edit</button>
      </div>`:''}
    </div>
  </div>`;
}

function advanceTask(id) {
  const t = DB.getById('tasks',id);
  const flow = {todo:'in-progress','in-progress':'review',review:'done'};
  const next = flow[t.status];
  if (!next) return;
  const updates = {status:next};
  if (next==='done') updates.completedAt = new Date().toISOString();
  DB.update('tasks',id,updates);
  renderTaskBoard();
  toast(`Task moved to ${next.replace(/-/g,' ')}!`,'success');
}

function openTaskDetail(id) {
  const t = DB.getById('tasks',id);
  if (!t) return;
  openModal('Task Detail', `
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem">
      ${statusBadge(t.status==='done'?'completed':t.status==='in-progress'?'in-progress':'not-started')}
      ${priorityBadge(t.priority)}
    </div>
    <div style="font-size:1.05rem;font-weight:700;margin-bottom:.5rem">${t.title}</div>
    <div style="font-size:.85rem;color:var(--text-muted);margin-bottom:.75rem">${projectName(t.projectId)}</div>
    ${t.description?`<p style="font-size:.875rem;margin-bottom:.75rem">${t.description}</p>`:''}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:.5rem;font-size:.85rem">
      <div><span class="text-muted">Assignee:</span> ${userName(t.assignee)||'–'}</div>
      <div><span class="text-muted">Due:</span> ${fmtDate(t.dueDate)}</div>
      <div><span class="text-muted">Created:</span> ${fmtDate(t.createdAt)}</div>
      ${t.completedAt?`<div><span class="text-muted">Completed:</span> ${fmtDate(t.completedAt)}</div>`:''}
    </div>
    <div class="modal-footer">
      <button class="btn-ghost" onclick="closeModal()">Close</button>
      ${Auth.can('write')?`<button class="btn-primary" onclick="closeModal();openTaskForm('${id}')">Edit</button>`:''}
    </div>
  `);
}

function openTaskForm(id, defaultStatus) {
  if (!Auth.can('write')) { toast('No permission','error'); return; }
  const t = id ? DB.getById('tasks',id) : {status:defaultStatus||'todo'};
  const projects = DB.getAll('projects');
  const users = DB.getAll('users').filter(u=>u.role!=='guest');
  openModal(id?'Edit Task':'New Task', `
    <div class="form-group"><label>Title *</label><input id="ttTitle" value="${t.title||''}" /></div>
    <div class="form-group"><label>Project *</label><select id="ttProject">
      ${projects.map(p=>`<option value="${p.id}" ${t.projectId===p.id?'selected':''}>${p.name}</option>`).join('')}
    </select></div>
    <div class="form-group"><label>Description</label><textarea id="ttDesc">${t.description||''}</textarea></div>
    <div class="form-row">
      <div class="form-group"><label>Status</label><select id="ttStatus">
        ${['todo','in-progress','review','done'].map(s=>`<option value="${s}" ${t.status===s?'selected':''}>${s}</option>`).join('')}
      </select></div>
      <div class="form-group"><label>Priority</label><select id="ttPriority">
        ${['high','medium','low'].map(s=>`<option ${t.priority===s?'selected':''}>${s}</option>`).join('')}
      </select></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Assignee</label><select id="ttAssignee">
        <option value="">Unassigned</option>
        ${users.map(u=>`<option value="${u.id}" ${t.assignee===u.id?'selected':''}>${u.name||u.username}</option>`).join('')}
      </select></div>
      <div class="form-group"><label>Due Date</label><input type="date" id="ttDue" value="${t.dueDate||''}" /></div>
    </div>
    <div class="modal-footer">
      <button class="btn-ghost" onclick="closeModal()">Cancel</button>
      ${id?`<button class="btn-danger" onclick="deleteTask('${id}')">Delete</button>`:''}
      <button class="btn-primary" onclick="saveTask('${id||''}')">Save</button>
    </div>
  `);
}

function saveTask(id) {
  const title = document.getElementById('ttTitle').value.trim();
  if (!title) { toast('Title required','error'); return; }
  const data = {
    title,
    projectId: document.getElementById('ttProject').value,
    description: document.getElementById('ttDesc').value,
    status: document.getElementById('ttStatus').value,
    priority: document.getElementById('ttPriority').value,
    assignee: document.getElementById('ttAssignee').value,
    dueDate: document.getElementById('ttDue').value
  };
  if (id) { DB.update('tasks',id,data); toast('Task updated!','success'); }
  else { DB.insert('tasks',{...data,createdAt:new Date().toISOString(),completedAt:null}); toast('Task created!','success'); }
  closeModal(); navigate('tasks');
}

function deleteTask(id) {
  if (!confirm('Delete this task?')) return;
  DB.delete('tasks',id);
  toast('Deleted','success');
  closeModal(); navigate('tasks');
}
