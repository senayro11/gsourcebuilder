// ============================================================
// app.js – Main application controller
// ============================================================

let currentPage = 'dashboard';

// ── INIT ────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  if (Auth.init()) {
    showApp();
  } else {
    show('loginScreen');
    hide('app');
  }
});

function showApp() {
  hide('loginScreen');
  show('app');
  applyRole();
  updateHeaderUser();
  updateNotifBadge();
  navigate('dashboard');
}

function applyRole() {
  const r = Auth.currentUser?.role || 'guest';
  document.body.className = `role-${r}`;
}

// ── LOGIN / LOGOUT ───────────────────────────────────────────
function doLogin() {
  const u = document.getElementById('loginUser').value.trim();
  const p = document.getElementById('loginPass').value;
  const user = Auth.login(u, p);
  if (user) {
    document.getElementById('loginError').classList.add('hidden');
    showApp();
  } else {
    document.getElementById('loginError').classList.remove('hidden');
  }
}

function guestLogin() {
  Auth.login('guest', 'guest');
  showApp();
}

function doLogout() {
  Auth.logout();
  location.reload();
}

// ─── ENTER key on login ───────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && document.getElementById('loginScreen') && !document.getElementById('loginScreen').classList.contains('hidden')) {
    doLogin();
  }
});

// ── NAVIGATION ───────────────────────────────────────────────
const pageMap = {
  dashboard: { title: 'Dashboard', label: 'Dashboard', render: renderDashboard },
  projects:  { title: 'Project List', label: 'Projects', render: renderProjects },
  tracker:   { title: 'Project Tracker', label: 'Tracker', render: renderTracker },
  gantt:     { title: 'Gantt Chart', label: 'Gantt Chart', render: renderGantt },
  costs:     { title: 'Project Cost', label: 'Costs', render: renderCosts },
  reports:   { title: 'Reports', label: 'Reports', render: renderReports },
  milestones:{ title: 'Milestones', label: 'Milestones', render: renderMilestones },
  tasks:     { title: 'Task Board', label: 'Tasks', render: renderTasks },
  team:      { title: 'Team Members', label: 'Team', render: renderTeam },
  users:     { title: 'User Management', label: 'Users', render: renderUsers },
  profile:   { title: 'My Profile', label: 'Profile', render: renderProfile }
};

function navigate(page) {
  if (!pageMap[page]) return;
  if (page === 'users' && !Auth.isAdmin()) { toast('Access denied', 'error'); return; }
  currentPage = page;

  // Update nav active state
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === page);
  });

  // Breadcrumb
  document.getElementById('breadcrumb').textContent = pageMap[page].label;

  // Close sidebar on mobile
  if (window.innerWidth < 768) closeSidebar();

  // Render page
  const area = document.getElementById('contentArea');
  area.innerHTML = '';
  pageMap[page].render(area);
}

// ── SIDEBAR ──────────────────────────────────────────────────
function toggleSidebar() {
  const sb = document.getElementById('sidebar');
  const mw = document.querySelector('.main-wrapper');
  if (window.innerWidth < 768) {
    sb.classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('visible', sb.classList.contains('open'));
  } else {
    sb.classList.toggle('collapsed');
    mw.classList.toggle('expanded', sb.classList.contains('collapsed'));
  }
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('visible');
}

// ── HEADER ───────────────────────────────────────────────────
function updateHeaderUser() {
  const u = Auth.currentUser;
  if (!u) return;
  const init = (u.name || u.username).charAt(0).toUpperCase();
  document.getElementById('headerUser').textContent = u.name || u.username;
  document.getElementById('headerAvatar').textContent = init;
  document.getElementById('sidebarUser').textContent = u.name || u.username;
  document.getElementById('sidebarRole').textContent = { admin:'Administrator', user:'Member', guest:'Guest Viewer' }[u.role] || u.role;
  document.getElementById('sidebarAvatar').textContent = init;
}

function toggleUserMenu() {
  document.getElementById('userDropdown').classList.toggle('hidden');
}
document.addEventListener('click', e => {
  if (!e.target.closest('.header-user')) document.getElementById('userDropdown')?.classList.add('hidden');
  if (!e.target.closest('.notif-btn') && !e.target.closest('.notif-panel')) document.getElementById('notifPanel')?.classList.add('hidden');
});

// ── NOTIFICATIONS ─────────────────────────────────────────────
function updateNotifBadge() {
  const notifs = DB.getAll('notifications').filter(n => !n.read);
  document.getElementById('notifBadge').textContent = notifs.length;
}

function toggleNotif() {
  const panel = document.getElementById('notifPanel');
  panel.classList.toggle('hidden');
  if (!panel.classList.contains('hidden')) renderNotifList();
}

function renderNotifList() {
  const notifs = DB.getAll('notifications');
  const list = document.getElementById('notifList');
  if (!notifs.length) {
    list.innerHTML = '<div class="empty-state" style="padding:1.5rem"><div class="empty-icon">🔔</div><p>No notifications</p></div>';
    return;
  }
  list.innerHTML = notifs.slice(0,10).map(n => `
    <div style="padding:.65rem 1rem;border-bottom:1px solid var(--border);font-size:.82rem">
      <div>${n.msg}</div>
      <div style="color:var(--text-muted);font-size:.72rem;margin-top:.2rem">${fmtRelTime(n.at)}</div>
    </div>
  `).join('');
  // Mark as read
  DB._data.notifications.forEach(n => n.read = true);
  DB.save();
  updateNotifBadge();
}

function clearNotifs() {
  DB.clearNotifs();
  updateNotifBadge();
  document.getElementById('notifPanel').classList.add('hidden');
}

// ── GLOBAL SEARCH ─────────────────────────────────────────────
function globalSearchFn(q) {
  const searchWrap = document.querySelector('.header-search');
  let results = document.getElementById('searchResults');
  if (!results) {
    results = document.createElement('div');
    results.id = 'searchResults';
    results.className = 'search-results';
    searchWrap.appendChild(results);
  }
  if (!q.trim()) { results.innerHTML = ''; return; }
  const projects = DB.where('projects', p => p.name.toLowerCase().includes(q.toLowerCase()) || p.code.toLowerCase().includes(q.toLowerCase()));
  const tasks = DB.where('tasks', t => t.title.toLowerCase().includes(q.toLowerCase()));
  if (!projects.length && !tasks.length) {
    results.innerHTML = '<div class="search-result-item text-muted">No results found</div>';
    return;
  }
  results.innerHTML = [
    ...projects.map(p => `<div class="search-result-item" onclick="navigate('projects');closeSearch()"><strong>${p.code}</strong> – ${p.name}</div>`),
    ...tasks.slice(0,5).map(t => `<div class="search-result-item" onclick="navigate('tasks');closeSearch()">Task: ${t.title}</div>`)
  ].join('');
}

function closeSearch() {
  const r = document.getElementById('searchResults');
  if (r) r.innerHTML = '';
  document.getElementById('globalSearch').value = '';
}

// ── MODAL ─────────────────────────────────────────────────────
function openModal(title, bodyHTML, { wide = false } = {}) {
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').innerHTML = bodyHTML;
  const box = document.getElementById('modalBox');
  box.style.maxWidth = wide ? '720px' : '540px';
  document.getElementById('modalOverlay').classList.remove('hidden');
}

function closeModal(e) {
  if (!e || e.target.id === 'modalOverlay' || e.target.closest('.modal-close')) {
    document.getElementById('modalOverlay').classList.add('hidden');
  }
}

// ── TOAST ─────────────────────────────────────────────────────
function toast(msg, type = 'info', duration = 3000) {
  const icons = { success: '✓', error: '✕', info: 'ℹ', warning: '⚠' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${icons[type] || '•'}</span><span>${msg}</span>`;
  document.getElementById('toastContainer').appendChild(el);
  setTimeout(() => el.remove(), duration);
}

// ── HELPERS ──────────────────────────────────────────────────
function show(id) { document.getElementById(id)?.classList.remove('hidden'); }
function hide(id) { document.getElementById(id)?.classList.add('hidden'); }

function fmtDate(d) {
  if (!d) return '–';
  return new Date(d).toLocaleDateString('en-PH', { year:'numeric', month:'short', day:'numeric' });
}
function fmtCurrency(n, currency = 'PHP') {
  return new Intl.NumberFormat('en-PH', { style:'currency', currency, maximumFractionDigits:0 }).format(n || 0);
}
function fmtRelTime(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  if (diff < 60000) return 'Just now';
  if (diff < 3600000) return `${Math.floor(diff/60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff/3600000)}h ago`;
  return `${Math.floor(diff/86400000)}d ago`;
}
function statusBadge(s) {
  const map = {
    'not-started': 'badge-gray', 'in-progress': 'badge-blue',
    'completed': 'badge-green', 'on-hold': 'badge-yellow', 'delayed': 'badge-red'
  };
  const label = { 'not-started':'Not Started','in-progress':'In Progress','completed':'Completed','on-hold':'On Hold','delayed':'Delayed' };
  return `<span class="badge ${map[s]||'badge-gray'}">${label[s]||s}</span>`;
}
function priorityBadge(p) {
  const map = { high:'badge-red', medium:'badge-yellow', low:'badge-green' };
  return `<span class="badge ${map[p]||'badge-gray'}">${p||'–'}</span>`;
}
function progressBar(pct, color='fill-blue') {
  return `<div class="progress-bar"><div class="progress-fill ${color}" style="width:${pct}%"></div></div><small style="color:var(--text-muted)">${pct}%</small>`;
}
function userName(uid) {
  const t = DB.getById('team','tm1');
  const teams = DB.getAll('team');
  const m = teams.find(tm => tm.userId === uid);
  if (m) return m.name;
  const u = DB.getById('users', uid);
  return u ? u.name : uid || '–';
}
function projectName(pid) { const p = DB.getById('projects', pid); return p ? p.name : pid; }

function daysLeft(endDate) {
  if (!endDate) return null;
  const diff = new Date(endDate) - new Date();
  return Math.ceil(diff / 86400000);
}

function renderProfile(area) {
  const u = Auth.currentUser;
  area.innerHTML = `
    <div class="page">
      <div class="page-header"><div><div class="page-title">My Profile</div></div></div>
      <div class="profile-hero">
        <div class="profile-avatar-lg">${(u.name||u.username).charAt(0).toUpperCase()}</div>
        <div>
          <div style="font-size:1.3rem;font-weight:700">${u.name||u.username}</div>
          <div style="opacity:.7;margin-top:.25rem">${u.email||''}</div>
          <div style="margin-top:.5rem"><span class="badge badge-blue">${u.role}</span></div>
        </div>
      </div>
      <div class="grid-2" style="gap:1rem">
        <div class="card">
          <div class="card-header"><div class="card-title">Account Info</div></div>
          <table><tbody>
            <tr><td class="text-muted">Username</td><td><strong>${u.username}</strong></td></tr>
            <tr><td class="text-muted">Name</td><td>${u.name||'–'}</td></tr>
            <tr><td class="text-muted">Email</td><td>${u.email||'–'}</td></tr>
            <tr><td class="text-muted">Department</td><td>${u.department||'–'}</td></tr>
            <tr><td class="text-muted">Role</td><td>${u.role}</td></tr>
          </tbody></table>
        </div>
        <div class="card">
          <div class="card-header"><div class="card-title">Change Password</div></div>
          <div class="form-group"><label>Current Password</label><input type="password" id="curPass" /></div>
          <div class="form-group"><label>New Password</label><input type="password" id="newPass" /></div>
          <div class="form-group"><label>Confirm Password</label><input type="password" id="conPass" /></div>
          <button class="btn-primary" onclick="changePassword()">Update Password</button>
        </div>
      </div>
    </div>`;
}

function changePassword() {
  const cur = document.getElementById('curPass').value;
  const nw = document.getElementById('newPass').value;
  const con = document.getElementById('conPass').value;
  const u = Auth.currentUser;
  if (cur !== u.password) { toast('Current password incorrect', 'error'); return; }
  if (nw !== con) { toast('Passwords do not match', 'error'); return; }
  if (nw.length < 4) { toast('Password too short', 'error'); return; }
  DB.update('users', u.id, { password: nw });
  Auth.currentUser.password = nw;
  toast('Password updated!', 'success');
}
