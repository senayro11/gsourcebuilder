// ============================================================
// costs.js
// ============================================================

function renderCosts(area) {
  const projects = DB.getAll('projects');
  area.innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Project Cost</div>
        <div class="page-subtitle">Track budgets and expenditures</div></div>
      ${Auth.can('write')?`<button class="btn-primary" onclick="openCostForm()">+ Log Cost</button>`:''}
    </div>

    <!-- TOTAL BANNER -->
    <div class="cost-total-bar">
      <div>
        <div class="cost-total-label">Total Budget (All Projects)</div>
        <div class="cost-total-value">${fmtCurrency(projects.reduce((s,p)=>s+p.budget,0))}</div>
      </div>
      <div style="text-align:right">
        <div class="cost-total-label">Total Spent</div>
        <div class="cost-total-value">${fmtCurrency(DB.getAll('costs').reduce((s,c)=>s+c.amount,0))}</div>
      </div>
    </div>

    <div class="filter-bar">
      <select id="cProject" onchange="filterCosts()">
        <option value="">All Projects</option>
        ${projects.map(p=>`<option value="${p.id}">${p.name}</option>`).join('')}
      </select>
      <select id="cCategory" onchange="filterCosts()">
        <option value="">All Categories</option>
        ${[...new Set(DB.getAll('costs').map(c=>c.category))].map(c=>`<option>${c}</option>`).join('')}
      </select>
    </div>

    <!-- PER PROJECT SUMMARY -->
    <div class="grid-auto" style="margin-bottom:1.25rem" id="costSummaryGrid"></div>

    <!-- COST TABLE -->
    <div class="card" id="costTable"></div>
  </div>`;
  filterCosts();
}

function filterCosts() {
  const pid = document.getElementById('cProject')?.value||'';
  const cat = document.getElementById('cCategory')?.value||'';
  let costs = DB.getAll('costs').filter(c=>
    (!pid||c.projectId===pid)&&(!cat||c.category===cat)
  );
  renderCostSummary(pid);
  renderCostTable(costs);
}

function renderCostSummary(pid) {
  const projects = pid ? [DB.getById('projects',pid)].filter(Boolean) : DB.getAll('projects');
  const grid = document.getElementById('costSummaryGrid');
  if (!grid) return;
  grid.innerHTML = projects.map(p => {
    const costs = DB.where('costs',c=>c.projectId===p.id);
    const spent = costs.reduce((s,c)=>s+c.amount,0);
    const pct = p.budget ? Math.min(100,spent/p.budget*100) : 0;
    const rem = p.budget - spent;
    return `<div class="card">
      <div style="font-weight:700;font-size:.9rem;margin-bottom:.25rem">${p.name}</div>
      <div style="font-size:.75rem;color:var(--text-muted);margin-bottom:.75rem">${p.code}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.5rem;font-size:.82rem;margin-bottom:.75rem">
        <div><div class="text-muted">Budget</div><div style="font-weight:700">${fmtCurrency(p.budget)}</div></div>
        <div><div class="text-muted">Spent</div><div style="font-weight:700;color:${pct>90?'var(--danger)':'var(--text)'}">${fmtCurrency(spent)}</div></div>
        <div><div class="text-muted">Remaining</div><div style="font-weight:700;color:${rem<0?'var(--danger)':'var(--success)'}">${fmtCurrency(rem)}</div></div>
        <div><div class="text-muted">Used</div><div style="font-weight:700">${pct.toFixed(1)}%</div></div>
      </div>
      <div class="progress-bar" style="height:8px">
        <div class="progress-fill ${pct>90?'fill-red':pct>70?'fill-yellow':'fill-green'}" style="width:${pct.toFixed(1)}%"></div>
      </div>
    </div>`;
  }).join('');
}

function renderCostTable(costs) {
  const table = document.getElementById('costTable');
  if (!table) return;
  if (!costs.length) {
    table.innerHTML = `<div class="empty-state"><div class="empty-icon">₱</div><p>No cost records found</p></div>`;
    return;
  }
  const total = costs.reduce((s,c)=>s+c.amount,0);
  table.innerHTML = `
    <div class="card-header">
      <div class="card-title">Cost Records</div>
      <strong>${fmtCurrency(total)}</strong>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Project</th><th>Category</th><th>Description</th><th>Amount</th><th>Date</th><th>Actions</th></tr></thead>
        <tbody>
          ${costs.map(c=>`<tr>
            <td style="font-weight:600">${projectName(c.projectId)}</td>
            <td><span class="badge badge-blue">${c.category}</span></td>
            <td>${c.description||'–'}</td>
            <td style="font-weight:700">${fmtCurrency(c.amount)}</td>
            <td>${fmtDate(c.date)}</td>
            <td>
              <div class="table-actions">
                ${Auth.can('write')?`<button class="btn-sm btn-secondary" onclick="openCostForm('${c.id}')">Edit</button>`:''}
                ${Auth.isAdmin()?`<button class="btn-sm btn-danger" onclick="deleteCost('${c.id}')">Del</button>`:''}
              </div>
            </td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

function openCostForm(id) {
  if (!Auth.can('write')) { toast('No permission','error'); return; }
  const c = id ? DB.getById('costs',id) : {};
  const projects = DB.getAll('projects');
  openModal(id?'Edit Cost':'Log Cost', `
    <div class="form-group"><label>Project *</label><select id="cProjId">
      ${projects.map(p=>`<option value="${p.id}" ${c.projectId===p.id?'selected':''}>${p.name}</option>`).join('')}
    </select></div>
    <div class="form-row">
      <div class="form-group"><label>Category</label>
        <select id="cCat">
          ${['Labor','Software','Hardware','Infrastructure','Consulting','Design','Marketing','Travel','Miscellaneous'].map(cat=>`<option ${c.category===cat?'selected':''}>${cat}</option>`).join('')}
        </select>
      </div>
      <div class="form-group"><label>Amount (₱) *</label><input type="number" id="cAmt" value="${c.amount||''}" /></div>
    </div>
    <div class="form-group"><label>Description</label><input id="cDesc" value="${c.description||''}" /></div>
    <div class="form-group"><label>Date</label><input type="date" id="cDate" value="${c.date||new Date().toISOString().slice(0,10)}" /></div>
    <div class="modal-footer">
      <button class="btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveCost('${id||''}')">Save</button>
    </div>
  `);
}

function saveCost(id) {
  const projectId = document.getElementById('cProjId').value;
  const amount = parseFloat(document.getElementById('cAmt').value);
  if (!amount) { toast('Amount required','error'); return; }
  const data = {
    projectId, amount,
    category: document.getElementById('cCat').value,
    description: document.getElementById('cDesc').value,
    date: document.getElementById('cDate').value
  };
  if (id) { DB.update('costs',id,data); toast('Cost updated!','success'); }
  else { DB.insert('costs',{...data,type:'actual'}); toast('Cost logged!','success'); }
  // Update project spent
  const allCosts = DB.where('costs',c=>c.projectId===projectId);
  const totalSpent = allCosts.reduce((s,c)=>s+c.amount,0);
  DB.update('projects',projectId,{spent:totalSpent});
  closeModal();
  navigate('costs');
}

function deleteCost(id) {
  if (!Auth.isAdmin()) { toast('Admin only','error'); return; }
  if (!confirm('Delete this cost record?')) return;
  const c = DB.getById('costs',id);
  DB.delete('costs',id);
  if (c) {
    const allCosts = DB.where('costs',cc=>cc.projectId===c.projectId);
    DB.update('projects',c.projectId,{spent:allCosts.reduce((s,cc)=>s+cc.amount,0)});
  }
  toast('Deleted','success');
  navigate('costs');
}
