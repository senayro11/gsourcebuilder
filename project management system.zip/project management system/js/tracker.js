// ============================================================
// tracker.js – Multi-project tracker
// ============================================================

function renderTracker(area) {
  const projects = DB.getAll('projects');
  area.innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Project Tracker</div>
        <div class="page-subtitle">Track progress across all projects</div></div>
      <div class="btn-group">
        <select id="trackerProject" onchange="renderTrackerDetail(this.value)" style="min-width:200px">
          <option value="">All Projects</option>
          ${projects.map(p=>`<option value="${p.id}">${p.name}</option>`).join('')}
        </select>
      </div>
    </div>
    <div id="trackerContent"></div>
  </div>`;
  renderTrackerDetail('');
}

function renderTrackerDetail(pid) {
  const container = document.getElementById('trackerContent');
  const projects = pid ? [DB.getById('projects', pid)] : DB.getAll('projects');

  container.innerHTML = `
    <!-- SUMMARY ROW -->
    <div class="stats-grid" style="margin-bottom:1.25rem">
      ${['not-started','in-progress','on-hold','completed','delayed'].map(s => {
        const cnt = projects.filter(p => p.status === s).length;
        const icons = {'not-started':'⭕','in-progress':'▶','on-hold':'⏸','completed':'✅','delayed':'⚠'};
        const colors = {'not-started':'gray','in-progress':'blue','on-hold':'yellow','completed':'green','delayed':'red'};
        return `<div class="stat-card ${colors[s]}"><div class="stat-icon">${icons[s]}</div>
          <div class="stat-info"><div class="stat-value">${cnt}</div>
          <div class="stat-label">${s.replace(/-/g,' ').replace(/\b\w/g,c=>c.toUpperCase())}</div></div></div>`;
      }).join('')}
    </div>

    <!-- PROJECT TRACKER ROWS -->
    <div style="display:flex;flex-direction:column;gap:.85rem">
      ${projects.map(p => renderTrackerRow(p)).join('')}
    </div>`;
}

function renderTrackerRow(p) {
  if (!p) return '';
  const tasks = DB.where('tasks', t => t.projectId === p.id);
  const milestones = DB.where('milestones', m => m.projectId === p.id);
  const costs = DB.where('costs', c => c.projectId === p.id);
  const totalCost = costs.reduce((s,c)=>s+c.amount, 0);
  const doneTasks = tasks.filter(t => t.status === 'done').length;
  const dl = daysLeft(p.endDate);
  const budgetPct = p.budget ? Math.min(100, (totalCost/p.budget*100)) : 0;

  const statusColors = {'not-started':'#94A3B8','in-progress':'#3B82F6','on-hold':'#F59E0B','completed':'#10B981','delayed':'#EF4444'};
  const sc = statusColors[p.status] || '#94A3B8';

  return `
  <div class="card" style="border-left:4px solid ${sc}">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:.5rem;margin-bottom:.85rem">
      <div>
        <div style="font-size:.7rem;font-weight:700;color:var(--text-muted);letter-spacing:.05em">${p.code}</div>
        <div style="font-size:1.05rem;font-weight:700;cursor:pointer" onclick="openProjectDetail('${p.id}')">${p.name}</div>
        <div style="font-size:.8rem;color:var(--text-muted)">${p.client||''} ${p.category?'· '+p.category:''}</div>
      </div>
      <div style="display:flex;gap:.5rem;flex-wrap:wrap;align-items:center">
        ${statusBadge(p.status)} ${priorityBadge(p.priority)}
        ${Auth.can('write')?`<button class="btn-sm btn-secondary" onclick="openUpdateProgress('${p.id}')">Update</button>`:''}
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin-bottom:1rem">
      <!-- Progress -->
      <div>
        <div style="font-size:.75rem;font-weight:600;color:var(--text-muted);margin-bottom:.4rem">PROGRESS</div>
        <div style="display:flex;align-items:center;gap:.6rem">
          <svg width="48" height="48" viewBox="0 0 48 48" style="flex-shrink:0">
            <circle cx="24" cy="24" r="18" fill="none" stroke="var(--border)" stroke-width="6"/>
            <circle cx="24" cy="24" r="18" fill="none" stroke="${sc}" stroke-width="6"
              stroke-dasharray="${2*Math.PI*18*((p.progress||0)/100)} ${2*Math.PI*18}"
              stroke-dashoffset="${2*Math.PI*18*0.25}" transform="rotate(-90 24 24)"/>
            <text x="24" y="28" text-anchor="middle" font-size="9" font-weight="700" fill="var(--text)">${p.progress||0}%</text>
          </svg>
          <div>
            <div style="font-size:.8rem">${doneTasks}/${tasks.length} tasks</div>
            <div style="font-size:.75rem;color:var(--text-muted)">${milestones.filter(m=>m.status==='completed').length}/${milestones.length} milestones</div>
          </div>
        </div>
      </div>

      <!-- Timeline -->
      <div>
        <div style="font-size:.75rem;font-weight:600;color:var(--text-muted);margin-bottom:.4rem">TIMELINE</div>
        <div style="font-size:.82rem">
          <div>Start: ${fmtDate(p.startDate)}</div>
          <div>End: ${fmtDate(p.endDate)}</div>
          <div style="margin-top:.3rem;font-weight:600;color:${dl===null?'var(--text-muted)':dl<0?'var(--danger)':dl<14?'var(--warning)':'var(--success)'}">
            ${dl === null ? '–' : dl < 0 ? `⚠ ${Math.abs(dl)}d overdue` : dl === 0 ? '⚠ Due today' : `✓ ${dl}d remaining`}
          </div>
        </div>
      </div>

      <!-- Budget -->
      <div>
        <div style="font-size:.75rem;font-weight:600;color:var(--text-muted);margin-bottom:.4rem">BUDGET</div>
        <div style="font-size:.82rem">
          <div>Budget: ${fmtCurrency(p.budget)}</div>
          <div>Spent: ${fmtCurrency(totalCost)}</div>
          <div class="progress-bar" style="margin-top:.3rem">
            <div class="progress-fill ${budgetPct>90?'fill-red':budgetPct>70?'fill-yellow':'fill-green'}" style="width:${budgetPct.toFixed(1)}%"></div>
          </div>
          <div style="font-size:.72rem;color:var(--text-muted)">${budgetPct.toFixed(1)}% used</div>
        </div>
      </div>

      <!-- Team -->
      <div>
        <div style="font-size:.75rem;font-weight:600;color:var(--text-muted);margin-bottom:.4rem">MANAGER</div>
        <div style="font-size:.85rem;font-weight:600">${userName(p.manager)}</div>
        <div style="font-size:.78rem;color:var(--text-muted)">${p.team?.length||0} team member(s)</div>
      </div>
    </div>

    <!-- TASK STATUS BAR -->
    ${tasks.length > 0 ? (() => {
      const tTodo = tasks.filter(t=>t.status==='todo').length;
      const tIP = tasks.filter(t=>t.status==='in-progress').length;
      const tDone = tasks.filter(t=>t.status==='done').length;
      const tAll = tasks.length;
      return `<div>
        <div style="font-size:.72rem;color:var(--text-muted);margin-bottom:.3rem">TASKS: ${tDone} done · ${tIP} in progress · ${tTodo} todo</div>
        <div style="display:flex;height:6px;border-radius:999px;overflow:hidden;gap:2px">
          ${tDone?`<div style="flex:${tDone};background:var(--success);border-radius:999px"></div>`:''}
          ${tIP?`<div style="flex:${tIP};background:var(--accent);border-radius:999px"></div>`:''}
          ${tTodo?`<div style="flex:${tTodo};background:var(--border);border-radius:999px"></div>`:''}
        </div>
      </div>`;
    })() : ''}

    <!-- MILESTONES -->
    ${milestones.length > 0 ? `
    <div style="margin-top:.75rem;padding-top:.75rem;border-top:1px solid var(--border)">
      <div style="font-size:.72rem;font-weight:700;color:var(--text-muted);margin-bottom:.4rem">MILESTONES</div>
      <div style="display:flex;gap:.5rem;flex-wrap:wrap">
        ${milestones.map(m=>`
          <span class="badge ${m.status==='completed'?'badge-green':daysLeft(m.dueDate)<0?'badge-red':'badge-blue'}" title="${m.description||''}">
            ${m.status==='completed'?'✓':''} ${m.title} · ${fmtDate(m.dueDate)}
          </span>`).join('')}
      </div>
    </div>` : ''}
  </div>`;
}

function openUpdateProgress(pid) {
  if (!Auth.can('write')) { toast('No permission','error'); return; }
  const p = DB.getById('projects', pid);
  openModal('Update Project Progress', `
    <p style="font-size:.9rem;margin-bottom:1rem">Updating: <strong>${p.name}</strong></p>
    <div class="form-group">
      <label>Progress (%) – Current: ${p.progress}%</label>
      <input type="range" id="upPct" min="0" max="100" value="${p.progress}" oninput="document.getElementById('upPctVal').textContent=this.value+'%'" style="width:100%;margin-bottom:.3rem" />
      <div id="upPctVal" style="text-align:center;font-weight:700;font-size:1.1rem">${p.progress}%</div>
    </div>
    <div class="form-group"><label>Status</label><select id="upStatus">
      ${['not-started','in-progress','on-hold','completed','delayed'].map(s=>`<option value="${s}" ${p.status===s?'selected':''}>${s}</option>`).join('')}
    </select></div>
    <div class="form-group"><label>Amount Spent (₱)</label><input type="number" id="upSpent" value="${p.spent||0}" /></div>
    <div class="form-group"><label>Notes / Update</label><textarea id="upNotes" placeholder="Add progress notes..."></textarea></div>
    <div class="modal-footer">
      <button class="btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveProgress('${pid}')">Save Update</button>
    </div>
  `);
}

function saveProgress(pid) {
  const pct = parseInt(document.getElementById('upPct').value);
  const status = document.getElementById('upStatus').value;
  const spent = parseFloat(document.getElementById('upSpent').value) || 0;
  const notes = document.getElementById('upNotes').value;
  DB.update('projects', pid, { progress: pct, status, spent });
  if (notes.trim()) {
    DB.addNotif(`Progress update on ${DB.getById('projects',pid)?.name}: ${pct}% – ${notes.slice(0,60)}`, 'info');
    updateNotifBadge();
  }
  toast('Progress updated!', 'success');
  closeModal();
  navigate('tracker');
}
