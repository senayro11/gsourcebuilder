// ============================================================
// projects.js
// ============================================================

function renderProjects(area) {
  area.innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Project List</div><div class="page-subtitle">Manage all your projects</div></div>
      ${Auth.can('write') ? `<button class="btn-primary" onclick="openProjectForm()">+ New Project</button>` : ''}
    </div>
    <div class="filter-bar">
      <select id="fStatus" onchange="filterProjects()"><option value="">All Status</option>
        <option>not-started</option><option>in-progress</option><option>on-hold</option><option>completed</option><option>delayed</option>
      </select>
      <select id="fPriority" onchange="filterProjects()"><option value="">All Priority</option>
        <option>high</option><option>medium</option><option>low</option>
      </select>
      <select id="fCategory" onchange="filterProjects()"><option value="">All Category</option>
        ${[...new Set(DB.getAll('projects').map(p=>p.category))].map(c=>`<option>${c}</option>`).join('')}
      </select>
      <input type="text" id="fSearch" placeholder="Search..." oninput="filterProjects()" />
      <div class="btn-group">
        <button class="btn-secondary btn-sm" onclick="setView('grid')" id="btnGrid">⊞ Grid</button>
        <button class="btn-secondary btn-sm" onclick="setView('table')" id="btnTable">≡ Table</button>
      </div>
    </div>
    <div id="projectsView"></div>
  </div>`;
  window._projView = 'grid';
  filterProjects();
}

function setView(v) {
  window._projView = v;
  document.getElementById('btnGrid').className = v === 'grid' ? 'btn-primary btn-sm' : 'btn-secondary btn-sm';
  document.getElementById('btnTable').className = v === 'table' ? 'btn-primary btn-sm' : 'btn-secondary btn-sm';
  filterProjects();
}

function filterProjects() {
  const status = document.getElementById('fStatus')?.value || '';
  const priority = document.getElementById('fPriority')?.value || '';
  const category = document.getElementById('fCategory')?.value || '';
  const q = (document.getElementById('fSearch')?.value || '').toLowerCase();
  let projs = DB.getAll('projects').filter(p =>
    (!status || p.status === status) &&
    (!priority || p.priority === priority) &&
    (!category || p.category === category) &&
    (!q || p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q) || (p.description||'').toLowerCase().includes(q))
  );
  const view = document.getElementById('projectsView');
  if (!projs.length) {
    view.innerHTML = `<div class="empty-state"><div class="empty-icon">📁</div><p>No projects found</p></div>`;
    return;
  }
  if (window._projView === 'grid') {
    view.innerHTML = `<div class="grid-auto">${projs.map(projCard).join('')}</div>`;
  } else {
    view.innerHTML = projTable(projs);
  }
}

function projCard(p) {
  const team = DB.getAll('team').filter(t => (p.team||[]).includes(t.userId) || p.manager === t.userId);
  const tasks = DB.where('tasks', t => t.projectId === p.id);
  const done = tasks.filter(t => t.status === 'done').length;
  return `
  <div class="project-card" onclick="openProjectDetail('${p.id}')">
    <div class="project-card-header">
      <div>
        <div style="font-size:.7rem;color:var(--text-muted);font-weight:600;letter-spacing:.05em">${p.code}</div>
        <div class="project-name">${p.name}</div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:.3rem">
        ${statusBadge(p.status)}
        ${priorityBadge(p.priority)}
      </div>
    </div>
    <div class="project-desc">${p.description||'No description'}</div>
    <div style="margin-bottom:.75rem">
      <div style="display:flex;justify-content:space-between;font-size:.75rem;margin-bottom:.3rem">
        <span class="text-muted">Progress</span><strong>${p.progress||0}%</strong>
      </div>
      <div class="progress-bar">
        <div class="progress-fill ${p.progress>=100?'fill-green':p.progress>=50?'fill-blue':'fill-yellow'}" style="width:${p.progress||0}%"></div>
      </div>
    </div>
    <div class="project-meta">
      <span>📅 ${fmtDate(p.endDate)}</span>
      <span>₱ ${fmtCurrency(p.budget)}</span>
      <span>✓ ${done}/${tasks.length} tasks</span>
    </div>
    <div class="project-footer">
      <div class="mini-team">
        ${team.slice(0,4).map(t=>`<div class="mini-avatar" title="${t.name}">${t.avatar||t.name.charAt(0)}</div>`).join('')}
        ${team.length>4?`<div class="mini-avatar">+${team.length-4}</div>`:''}
      </div>
      ${Auth.can('write')?`<div class="btn-group" onclick="event.stopPropagation()">
        <button class="btn-sm btn-secondary" onclick="openProjectForm('${p.id}')">Edit</button>
        <button class="btn-sm btn-danger" onclick="deleteProject('${p.id}')">Del</button>
      </div>`:''}
    </div>
  </div>`;
}

function projTable(projs) {
  return `<div class="card"><div class="table-wrap"><table>
    <thead><tr><th>Code</th><th>Name</th><th>Status</th><th>Priority</th><th>Progress</th><th>Budget</th><th>Due Date</th><th>Actions</th></tr></thead>
    <tbody>${projs.map(p=>`
      <tr>
        <td style="font-weight:600;color:var(--accent)">${p.code}</td>
        <td>
          <div style="font-weight:600">${p.name}</div>
          <div style="font-size:.75rem;color:var(--text-muted)">${p.category}</div>
        </td>
        <td>${statusBadge(p.status)}</td>
        <td>${priorityBadge(p.priority)}</td>
        <td style="min-width:120px">${progressBar(p.progress||0)}</td>
        <td>
          <div>${fmtCurrency(p.budget)}</div>
          <div style="font-size:.72rem;color:var(--text-muted)">${fmtCurrency(p.spent)} spent</div>
        </td>
        <td style="white-space:nowrap">${fmtDate(p.endDate)}</td>
        <td>
          <div class="table-actions">
            <button class="btn-sm btn-secondary" onclick="openProjectDetail('${p.id}')">View</button>
            ${Auth.can('write')?`<button class="btn-sm btn-secondary" onclick="openProjectForm('${p.id}')">Edit</button>`:''}
            ${Auth.isAdmin()?`<button class="btn-sm btn-danger" onclick="deleteProject('${p.id}')">Del</button>`:''}
          </div>
        </td>
      </tr>`).join('')}
    </tbody>
  </table></div></div>`;
}

function openProjectForm(id) {
  if (!Auth.can('write')) { toast('No permission', 'error'); return; }
  const p = id ? DB.getById('projects', id) : {};
  const users = DB.getAll('users').filter(u => u.role !== 'guest');
  openModal(id ? 'Edit Project' : 'New Project', `
    <div class="form-row">
      <div class="form-group"><label>Project Name *</label><input id="pName" value="${p.name||''}" /></div>
      <div class="form-group"><label>Project Code *</label><input id="pCode" value="${p.code||''}" placeholder="e.g. PR-001" /></div>
    </div>
    <div class="form-group"><label>Description</label><textarea id="pDesc">${p.description||''}</textarea></div>
    <div class="form-row">
      <div class="form-group"><label>Status</label><select id="pStatus">
        ${['not-started','in-progress','on-hold','completed','delayed'].map(s=>`<option ${p.status===s?'selected':''}>${s}</option>`).join('')}
      </select></div>
      <div class="form-group"><label>Priority</label><select id="pPriority">
        ${['high','medium','low'].map(s=>`<option ${p.priority===s?'selected':''}>${s}</option>`).join('')}
      </select></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Start Date</label><input type="date" id="pStart" value="${p.startDate||''}" /></div>
      <div class="form-group"><label>End Date</label><input type="date" id="pEnd" value="${p.endDate||''}" /></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Budget (₱)</label><input type="number" id="pBudget" value="${p.budget||''}" /></div>
      <div class="form-group"><label>Amount Spent (₱)</label><input type="number" id="pSpent" value="${p.spent||''}" /></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Progress (%)</label><input type="number" id="pProgress" min="0" max="100" value="${p.progress||0}" /></div>
      <div class="form-group"><label>Category</label><input id="pCategory" value="${p.category||''}" placeholder="e.g. IT, Marketing" /></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Client</label><input id="pClient" value="${p.client||''}" /></div>
      <div class="form-group"><label>Project Manager</label><select id="pManager">
        ${users.map(u=>`<option value="${u.id}" ${p.manager===u.id?'selected':''}>${u.name||u.username}</option>`).join('')}
      </select></div>
    </div>
    <div class="modal-footer">
      <button class="btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveProject('${id||''}')">Save Project</button>
    </div>
  `, { wide: true });
}

function saveProject(id) {
  const name = document.getElementById('pName').value.trim();
  const code = document.getElementById('pCode').value.trim();
  if (!name || !code) { toast('Name and code required', 'error'); return; }
  const data = {
    name, code,
    description: document.getElementById('pDesc').value,
    status: document.getElementById('pStatus').value,
    priority: document.getElementById('pPriority').value,
    startDate: document.getElementById('pStart').value,
    endDate: document.getElementById('pEnd').value,
    budget: parseFloat(document.getElementById('pBudget').value) || 0,
    spent: parseFloat(document.getElementById('pSpent').value) || 0,
    progress: parseInt(document.getElementById('pProgress').value) || 0,
    category: document.getElementById('pCategory').value,
    client: document.getElementById('pClient').value,
    manager: document.getElementById('pManager').value,
    team: [document.getElementById('pManager').value]
  };
  if (id) { DB.update('projects', id, data); toast('Project updated!', 'success'); }
  else { DB.insert('projects', { ...data, createdAt: new Date().toISOString() }); toast('Project created!', 'success'); DB.addNotif(`New project: ${name}`, 'info'); updateNotifBadge(); }
  closeModal();
  navigate('projects');
}

function openProjectDetail(id) {
  const p = DB.getById('projects', id);
  if (!p) return;
  const tasks = DB.where('tasks', t => t.projectId === id);
  const milestones = DB.where('milestones', m => m.projectId === id);
  const costs = DB.where('costs', c => c.projectId === id);
  const totalCost = costs.reduce((s, c) => s + c.amount, 0);
  openModal(`${p.code} – ${p.name}`, `
    <div style="display:flex;gap:.75rem;flex-wrap:wrap;margin-bottom:1rem">
      ${statusBadge(p.status)} ${priorityBadge(p.priority)}
      <span class="badge badge-gray">${p.category}</span>
    </div>
    <p style="font-size:.875rem;color:var(--text-muted);margin-bottom:1rem">${p.description||'No description'}</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-bottom:1rem;font-size:.85rem">
      <div><span class="text-muted">Start:</span> ${fmtDate(p.startDate)}</div>
      <div><span class="text-muted">End:</span> ${fmtDate(p.endDate)}</div>
      <div><span class="text-muted">Budget:</span> ${fmtCurrency(p.budget)}</div>
      <div><span class="text-muted">Spent:</span> ${fmtCurrency(totalCost)}</div>
      <div><span class="text-muted">Manager:</span> ${userName(p.manager)}</div>
      <div><span class="text-muted">Client:</span> ${p.client||'–'}</div>
    </div>
    <div style="margin-bottom:1rem">
      <div style="font-size:.78rem;font-weight:700;color:var(--text-muted);margin-bottom:.4rem">OVERALL PROGRESS</div>
      <div class="progress-bar" style="height:10px;margin-bottom:.3rem">
        <div class="progress-fill fill-blue" style="width:${p.progress}%"></div>
      </div>
      <div style="font-size:.8rem;text-align:right">${p.progress}%</div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.5rem;margin-bottom:1rem;text-align:center">
      <div style="background:var(--bg);border-radius:8px;padding:.6rem">
        <div style="font-size:1.2rem;font-weight:700">${tasks.length}</div>
        <div class="text-muted" style="font-size:.72rem">Tasks</div>
      </div>
      <div style="background:var(--bg);border-radius:8px;padding:.6rem">
        <div style="font-size:1.2rem;font-weight:700">${milestones.length}</div>
        <div class="text-muted" style="font-size:.72rem">Milestones</div>
      </div>
      <div style="background:var(--bg);border-radius:8px;padding:.6rem">
        <div style="font-size:1.2rem;font-weight:700">${tasks.filter(t=>t.status==='done').length}</div>
        <div class="text-muted" style="font-size:.72rem">Done</div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-ghost" onclick="closeModal()">Close</button>
      ${Auth.can('write') ? `<button class="btn-primary" onclick="closeModal();openProjectForm('${id}')">Edit Project</button>` : ''}
    </div>
  `, { wide: true });
}

function deleteProject(id) {
  if (!Auth.isAdmin()) { toast('Admin only', 'error'); return; }
  if (!confirm('Delete this project? This will also remove related tasks, milestones, and costs.')) return;
  DB.delete('projects', id);
  DB.where('tasks', t => t.projectId === id).forEach(t => DB.delete('tasks', t.id));
  DB.where('milestones', m => m.projectId === id).forEach(m => DB.delete('milestones', m.id));
  DB.where('costs', c => c.projectId === id).forEach(c => DB.delete('costs', c.id));
  toast('Project deleted', 'success');
  navigate('projects');
}
