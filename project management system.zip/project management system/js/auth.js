// ============================================================
// auth.js – Authentication & session management
// ============================================================

const Auth = {
  currentUser: null,

  init() {
    const saved = sessionStorage.getItem('protrack_session');
    if (saved) {
      try {
        const user = JSON.parse(saved);
        // Verify user still exists
        const dbUser = DB.getById('users', user.id);
        if (dbUser && dbUser.active !== false) {
          this.currentUser = dbUser;
          return true;
        }
      } catch {}
    }
    return false;
  },

  login(username, password) {
    const users = DB.getAll('users');
    const user = users.find(u => u.username === username && u.password === password && u.active !== false);
    if (!user) return false;
    this.currentUser = user;
    sessionStorage.setItem('protrack_session', JSON.stringify(user));
    return user;
  },

  logout() {
    this.currentUser = null;
    sessionStorage.removeItem('protrack_session');
  },

  isLoggedIn() { return !!this.currentUser; },
  isAdmin() { return this.currentUser?.role === 'admin'; },
  isUser() { return this.currentUser?.role === 'user'; },
  isGuest() { return this.currentUser?.role === 'guest'; },
  can(action) {
    if (!this.currentUser) return false;
    const role = this.currentUser.role;
    const perms = {
      admin: ['read','write','delete','manage_users'],
      user:  ['read','write'],
      guest: ['read']
    };
    return (perms[role] || []).includes(action);
  }
};
