// ============================================================
// reports.js
// ============================================================

function renderReports(area) {
  area.innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">Reports</div>
        <div class="page-subtitle">Analytics and project summaries</div></div>
      <div class="btn-group">
        <button class="btn-secondary" onclick="window.print()">🖨 Print</button>
        <button class="btn-primary" onclick="exportReport()">⬇ Export</button>
      </div>
    </div>
    <div class="tabs">
      <div class="tab active" onclick="switchReportTab('overview',this)">Overview</div>
      <div class="tab" onclick="switchReportTab('budget',this)">Budget</div>
      <div class="tab" onclick="switchReportTab('progress',this)">Progress</div>
      <div class="tab" onclick="switchReportTab('timeline',this)">Timeline</div>
    </div>
    <div id="reportContent"></div>
  </div>`;
  renderReportOverview();
}

function switchReportTab(tab, el) {
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  const fns = { overview:renderReportOverview, budget:renderReportBudget, progress:renderReportProgress, timeline:renderReportTimeline };
  (fns[tab]||renderReportOverview)();
}

function renderReportOverview() {
  const projects = DB.getAll('projects');
  const tasks = DB.getAll('tasks');
  const costs = DB.getAll('costs');

  const byStatus = {};
  projects.forEach(p => { byStatus[p.status] = (byStatus[p.status]||0)+1; });
  const byPriority = {};
  projects.forEach(p => { byPriority[p.priority] = (byPriority[p.priority]||0)+1; });

  const totalBudget = projects.reduce((s,p)=>s+p.budget,0);
  const totalSpent = costs.reduce((s,c)=>s+c.amount,0);
  const avgProgress = projects.length ? Math.round(projects.reduce((s,p)=>s+(p.progress||0),0)/projects.length) : 0;
  const overdue = projects.filter(p=>p.endDate&&new Date(p.endDate)<new Date()&&p.status!=='completed').length;

  document.getElementById('reportContent').innerHTML = `
    <div class="stats-grid" style="margin-bottom:1.25rem">
      <div class="stat-card blue"><div class="stat-icon">📁</div><div class="stat-info"><div class="stat-value">${projects.length}</div><div class="stat-label">Total Projects</div></div></div>
      <div class="stat-card green"><div class="stat-icon">✓</div><div class="stat-info"><div class="stat-value">${projects.filter(p=>p.status==='completed').length}</div><div class="stat-label">Completed</div></div></div>
      <div class="stat-card yellow"><div class="stat-icon">⚡</div><div class="stat-info"><div class="stat-value">${avgProgress}%</div><div class="stat-label">Avg Progress</div></div></div>
      <div class="stat-card red"><div class="stat-icon">⚠</div><div class="stat-info"><div class="stat-value">${overdue}</div><div class="stat-label">Overdue</div></div></div>
    </div>

    <div class="grid-2" style="gap:1rem;margin-bottom:1rem">
      <div class="card">
        <div class="card-header"><div class="card-title">Projects by Status</div></div>
        ${Object.entries(byStatus).map(([s,n])=>{
          const colors={'not-started':'#94A3B8','in-progress':'#3B82F6','on-hold':'#F59E0B','completed':'#10B981','delayed':'#EF4444'};
          const pct = (n/projects.length*100).toFixed(1);
          return `<div style="margin-bottom:.6rem">
            <div style="display:flex;justify-content:space-between;font-size:.82rem;margin-bottom:.25rem">
              <span>${s.replace(/-/g,' ')}</span><span style="font-weight:700">${n} (${pct}%)</span>
            </div>
            <div class="progress-bar"><div class="progress-fill" style="width:${pct}%;background:${colors[s]}"></div></div>
          </div>`;
        }).join('')}
      </div>
      <div class="card">
        <div class="card-header"><div class="card-title">Projects by Priority</div></div>
        ${Object.entries(byPriority).map(([p,n])=>{
          const c={high:'#EF4444',medium:'#F59E0B',low:'#10B981'}[p]||'#94A3B8';
          const pct=(n/projects.length*100).toFixed(1);
          return `<div style="margin-bottom:.6rem">
            <div style="display:flex;justify-content:space-between;font-size:.82rem;margin-bottom:.25rem">
              <span style="text-transform:capitalize">${p}</span><span style="font-weight:700">${n} (${pct}%)</span>
            </div>
            <div class="progress-bar"><div class="progress-fill" style="width:${pct}%;background:${c}"></div></div>
          </div>`;
        }).join('')}
      </div>
    </div>

    <div class="card">
      <div class="card-header"><div class="card-title">Project Summary Table</div></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Code</th><th>Name</th><th>Status</th><th>Progress</th><th>Budget</th><th>Spent</th><th>Variance</th><th>Due</th></tr></thead>
          <tbody>
            ${projects.map(p=>{
              const spent = DB.where('costs',c=>c.projectId===p.id).reduce((s,c)=>s+c.amount,0);
              const variance = p.budget - spent;
              return `<tr>
                <td style="font-weight:600;color:var(--accent)">${p.code}</td>
                <td style="font-weight:500">${p.name}</td>
                <td>${statusBadge(p.status)}</td>
                <td style="min-width:100px">${progressBar(p.progress||0)}</td>
                <td>${fmtCurrency(p.budget)}</td>
                <td>${fmtCurrency(spent)}</td>
                <td style="color:${variance<0?'var(--danger)':'var(--success)'}">
                  ${variance<0?'▼':'▲'} ${fmtCurrency(Math.abs(variance))}
                </td>
                <td>${fmtDate(p.endDate)}</td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>`;
}

function renderReportBudget() {
  const projects = DB.getAll('projects');
  const costs = DB.getAll('costs');
  const byCat = {};
  costs.forEach(c => { byCat[c.category] = (byCat[c.category]||0)+c.amount; });
  const maxCat = Math.max(...Object.values(byCat),1);
  const totalBudget = projects.reduce((s,p)=>s+p.budget,0);
  const totalSpent = costs.reduce((s,c)=>s+c.amount,0);

  document.getElementById('reportContent').innerHTML = `
    <div class="grid-2" style="gap:1rem;margin-bottom:1rem">
      <div class="card">
        <div class="card-header"><div class="card-title">Spending by Category</div></div>
        ${Object.entries(byCat).sort((a,b)=>b[1]-a[1]).map(([cat,amt])=>`
          <div style="margin-bottom:.75rem">
            <div style="display:flex;justify-content:space-between;font-size:.82rem;margin-bottom:.3rem">
              <span>${cat}</span><strong>${fmtCurrency(amt)}</strong>
            </div>
            <div class="progress-bar" style="height:8px">
              <div class="progress-fill fill-blue" style="width:${(amt/maxCat*100).toFixed(1)}%"></div>
            </div>
          </div>`).join('')}
      </div>
      <div class="card">
        <div class="card-header"><div class="card-title">Budget vs Actual by Project</div></div>
        ${projects.map(p=>{
          const spent = DB.where('costs',c=>c.projectId===p.id).reduce((s,c)=>s+c.amount,0);
          const pct = p.budget ? Math.min(100,spent/p.budget*100) : 0;
          return `<div style="margin-bottom:.75rem">
            <div style="display:flex;justify-content:space-between;font-size:.8rem;margin-bottom:.3rem">
              <span style="font-weight:600">${p.name}</span>
              <span style="color:${pct>90?'var(--danger)':'var(--text-muted)'}">${fmtCurrency(spent)} / ${fmtCurrency(p.budget)}</span>
            </div>
            <div class="progress-bar" style="height:8px">
              <div class="progress-fill ${pct>90?'fill-red':pct>70?'fill-yellow':'fill-green'}" style="width:${pct.toFixed(1)}%"></div>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title">All Cost Records</div></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Project</th><th>Category</th><th>Description</th><th>Amount</th><th>Date</th></tr></thead>
          <tbody>
            ${costs.map(c=>`<tr>
              <td>${projectName(c.projectId)}</td>
              <td><span class="badge badge-blue">${c.category}</span></td>
              <td>${c.description||'–'}</td>
              <td style="font-weight:600">${fmtCurrency(c.amount)}</td>
              <td>${fmtDate(c.date)}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`;
}

function renderReportProgress() {
  const projects = DB.getAll('projects');
  document.getElementById('reportContent').innerHTML = `
    <div class="card">
      <div class="card-header"><div class="card-title">Project Progress Overview</div></div>
      ${projects.map(p => {
        const tasks = DB.where('tasks',t=>t.projectId===p.id);
        const done = tasks.filter(t=>t.status==='done').length;
        return `<div style="margin-bottom:1.1rem;padding-bottom:1.1rem;border-bottom:1px solid var(--border)">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.4rem">
            <div>
              <span style="font-weight:700">${p.name}</span>
              <span style="font-size:.75rem;color:var(--text-muted);margin-left:.5rem">${p.code}</span>
            </div>
            <div style="display:flex;align-items:center;gap:.75rem">
              ${statusBadge(p.status)}
              <strong style="font-size:1rem">${p.progress||0}%</strong>
            </div>
          </div>
          <div class="progress-bar" style="height:10px;margin-bottom:.4rem">
            <div class="progress-fill ${p.progress>=100?'fill-green':p.progress>=50?'fill-blue':'fill-yellow'}" style="width:${p.progress||0}%"></div>
          </div>
          <div style="font-size:.75rem;color:var(--text-muted);display:flex;gap:1rem">
            <span>Tasks: ${done}/${tasks.length} done</span>
            <span>Due: ${fmtDate(p.endDate)}</span>
            <span style="color:${daysLeft(p.endDate)<0?'var(--danger)':daysLeft(p.endDate)<14?'var(--warning)':'inherit'}">
              ${daysLeft(p.endDate)!==null?daysLeft(p.endDate)<0?`${Math.abs(daysLeft(p.endDate))}d overdue`:`${daysLeft(p.endDate)}d left`:''}
            </span>
          </div>
        </div>`;
      }).join('')}
    </div>`;
}

function renderReportTimeline() {
  const projects = DB.getAll('projects');
  const milestones = DB.getAll('milestones');
  const events = [
    ...projects.map(p=>({date:p.endDate,label:`Project Due: ${p.name}`,type:'project',status:p.status})),
    ...milestones.map(m=>({date:m.dueDate,label:`Milestone: ${m.title} (${projectName(m.projectId)})`,type:'milestone',status:m.status}))
  ].filter(e=>e.date).sort((a,b)=>new Date(a.date)-new Date(b.date));

  document.getElementById('reportContent').innerHTML = `
    <div class="card">
      <div class="card-header"><div class="card-title">Event Timeline</div></div>
      <div class="timeline">
        ${events.map(e=>{
          const isPast = new Date(e.date)<new Date();
          const isDone = e.status==='completed';
          const dotClass = isDone?'green':isPast?'red':'';
          return `<div class="timeline-item">
            <div class="timeline-dot ${dotClass}"></div>
            <div class="timeline-content">
              <div class="timeline-title">${e.label}</div>
              <div class="timeline-meta">${fmtDate(e.date)} · ${isDone?'✓ Completed':isPast?'⚠ Overdue':'Upcoming'}</div>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>`;
}

function exportReport() {
  const projects = DB.getAll('projects');
  const costs = DB.getAll('costs');
  const tasks = DB.getAll('tasks');
  const lines = [
    'ProTrack – Project Report',
    `Generated: ${new Date().toLocaleString()}`,
    '='.repeat(60),
    '',
    'PROJECT SUMMARY',
    '-'.repeat(40),
    ...projects.map(p => {
      const spent = DB.where('costs',c=>c.projectId===p.id).reduce((s,c)=>s+c.amount,0);
      return `${p.code} | ${p.name} | ${p.status} | ${p.progress}% | Budget: ${fmtCurrency(p.budget)} | Spent: ${fmtCurrency(spent)} | Due: ${fmtDate(p.endDate)}`;
    }),
    '',
    'COST RECORDS',
    '-'.repeat(40),
    ...costs.map(c=>`${fmtDate(c.date)} | ${projectName(c.projectId)} | ${c.category} | ${fmtCurrency(c.amount)} | ${c.description||''}`),
    '',
    'TASK SUMMARY',
    '-'.repeat(40),
    ...tasks.map(t=>`${projectName(t.projectId)} | ${t.title} | ${t.status} | ${t.priority} | Due: ${fmtDate(t.dueDate)}`)
  ];
  const blob = new Blob([lines.join('\n')], {type:'text/plain'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `protrack_report_${new Date().toISOString().slice(0,10)}.txt`;
  a.click();
  toast('Report exported!','success');
}
