// ============================================================
// users.js – Admin only
// ============================================================

function renderUsers(area) {
  if (!Auth.isAdmin()) {
    area.innerHTML = `<div class="empty-state"><div class="empty-icon">🔒</div><p>Admin access required</p></div>`;
    return;
  }
  area.innerHTML = `
  <div class="page">
    <div class="page-header">
      <div><div class="page-title">User Management</div>
        <div class="page-subtitle">Manage system access and roles</div></div>
      <button class="btn-primary" onclick="openUserForm()">+ New User</button>
    </div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>User</th><th>Username</th><th>Email</th><th>Role</th><th>Department</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody id="usersTableBody"></tbody>
        </table>
      </div>
    </div>

    <div class="grid-2" style="gap:1rem;margin-top:1rem">
      <div class="card">
        <div class="card-header"><div class="card-title">Role Permissions</div></div>
        <table>
          <thead><tr><th>Permission</th><th>Admin</th><th>User</th><th>Guest</th></tr></thead>
          <tbody>
            ${[
              ['View Projects','✓','✓','✓'],
              ['Create/Edit','✓','✓','✗'],
              ['Delete','✓','✗','✗'],
              ['Manage Users','✓','✗','✗'],
              ['Export Reports','✓','✓','✗'],
              ['View Costs','✓','✓','✓'],
              ['Log Costs','✓','✓','✗'],
            ].map(([perm,...vals])=>`<tr>
              <td>${perm}</td>
              ${vals.map(v=>`<td style="text-align:center;color:${v==='✓'?'var(--success)':'var(--danger)'}"><strong>${v}</strong></td>`).join('')}
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div class="card">
        <div class="card-header"><div class="card-title">Data Management</div></div>
        <div style="display:flex;flex-direction:column;gap:.75rem">
          <div>
            <div style="font-weight:600;margin-bottom:.25rem">Backup Data</div>
            <div style="font-size:.82rem;color:var(--text-muted);margin-bottom:.5rem">Export all data as a .txt file</div>
            <button class="btn-secondary" onclick="DB.exportTxt();toast('Backup exported!','success')">⬇ Export Backup</button>
          </div>
          <div style="border-top:1px solid var(--border);padding-top:.75rem">
            <div style="font-weight:600;margin-bottom:.25rem">Import Data</div>
            <div style="font-size:.82rem;color:var(--text-muted);margin-bottom:.5rem">Restore from a .txt backup file</div>
            <input type="file" id="importFile" accept=".txt,.json" style="display:none" onchange="importBackup(this)" />
            <button class="btn-secondary" onclick="document.getElementById('importFile').click()">⬆ Import Backup</button>
          </div>
          <div style="border-top:1px solid var(--border);padding-top:.75rem">
            <div style="font-weight:600;margin-bottom:.25rem;color:var(--danger)">Reset System</div>
            <div style="font-size:.82rem;color:var(--text-muted);margin-bottom:.5rem">Restore all demo data (destructive)</div>
            <button class="btn-danger" onclick="resetSystem()">↺ Reset to Demo</button>
          </div>
        </div>
      </div>
    </div>
  </div>`;
  refreshUsersTable();
}

function refreshUsersTable() {
  const body = document.getElementById('usersTableBody');
  if (!body) return;
  const users = DB.getAll('users');
  body.innerHTML = users.map(u => `
    <tr>
      <td>
        <div style="display:flex;align-items:center;gap:.6rem">
          <div class="avatar sm">${(u.name||u.username).charAt(0).toUpperCase()}</div>
          <div style="font-weight:600">${u.name||u.username}</div>
        </div>
      </td>
      <td style="font-family:monospace;font-size:.82rem">${u.username}</td>
      <td>${u.email||'–'}</td>
      <td>
        <span class="badge ${u.role==='admin'?'badge-red':u.role==='user'?'badge-blue':'badge-gray'}">${u.role}</span>
      </td>
      <td>${u.department||'–'}</td>
      <td>
        <span class="badge ${u.active!==false?'badge-green':'badge-gray'}">${u.active!==false?'Active':'Inactive'}</span>
      </td>
      <td>
        <div class="table-actions">
          <button class="btn-sm btn-secondary" onclick="openUserForm('${u.id}')">Edit</button>
          ${u.id !== Auth.currentUser?.id ? `<button class="btn-sm btn-danger" onclick="toggleUserActive('${u.id}',${u.active!==false})">${u.active!==false?'Deactivate':'Activate'}</button>` : '<span class="text-muted" style="font-size:.75rem">You</span>'}
        </div>
      </td>
    </tr>`).join('');
}

function openUserForm(id) {
  const u = id ? DB.getById('users',id) : {};
  openModal(id?'Edit User':'New User', `
    <div class="form-row">
      <div class="form-group"><label>Full Name *</label><input id="unName" value="${u.name||''}" /></div>
      <div class="form-group"><label>Username *</label><input id="unUser" value="${u.username||''}" /></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Password ${id?'(leave blank to keep)':' *'}</label><input type="password" id="unPass" /></div>
      <div class="form-group"><label>Role</label><select id="unRole">
        ${['admin','user','guest'].map(r=>`<option ${u.role===r?'selected':''}>${r}</option>`).join('')}
      </select></div>
    </div>
    <div class="form-group"><label>Email</label><input type="email" id="unEmail" value="${u.email||''}" /></div>
    <div class="form-group"><label>Department</label><input id="unDept" value="${u.department||''}" /></div>
    <div class="modal-footer">
      <button class="btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveUser('${id||''}')">Save User</button>
    </div>
  `);
}

function saveUser(id) {
  const name = document.getElementById('unName').value.trim();
  const username = document.getElementById('unUser').value.trim();
  const pass = document.getElementById('unPass').value;
  if (!name || !username) { toast('Name and username required','error'); return; }
  if (!id && !pass) { toast('Password required for new user','error'); return; }

  // Check duplicate username
  const existing = DB.getAll('users').find(u=>u.username===username&&u.id!==id);
  if (existing) { toast('Username already taken','error'); return; }

  const data = { name, username, role: document.getElementById('unRole').value, email: document.getElementById('unEmail').value, department: document.getElementById('unDept').value, active: true };
  if (pass) data.password = pass;
  if (id) { DB.update('users',id,data); toast('User updated!','success'); }
  else { DB.insert('users',{...data,createdAt:new Date().toISOString()}); toast('User created!','success'); }
  closeModal(); refreshUsersTable();
}

function toggleUserActive(id, currentlyActive) {
  if (id === Auth.currentUser?.id) { toast('Cannot deactivate yourself','error'); return; }
  DB.update('users',id,{active:!currentlyActive});
  toast(currentlyActive?'User deactivated':'User activated','success');
  refreshUsersTable();
}

function importBackup(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    if (DB.importTxt(e.target.result)) {
      toast('Data imported successfully! Reloading...','success');
      setTimeout(()=>location.reload(), 1500);
    } else {
      toast('Import failed – invalid file format','error');
    }
  };
  reader.readAsText(file);
}

function resetSystem() {
  if (!confirm('This will reset ALL data to demo defaults. Continue?')) return;
  DB.reset();
  toast('System reset to demo data. Reloading...','info');
  setTimeout(()=>location.reload(), 1500);
}
