# ProTrack – Project Management System

A full-featured, multi-project management system built with HTML, CSS, and JavaScript.  
**100% client-side** – no backend needed. Works on GitHub Pages.

## 🚀 Deploy to GitHub Pages

1. Create a new GitHub repository (e.g. `protrack`)
2. Upload all files maintaining the folder structure:
   ```
   index.html
   css/style.css
   css/gantt.css
   js/db.js
   js/auth.js
   js/app.js
   js/pages/dashboard.js
   js/pages/projects.js
   js/pages/tracker.js
   js/pages/gantt.js
   js/pages/costs.js
   js/pages/reports.js
   js/pages/milestones.js
   js/pages/tasks.js
   js/pages/team.js
   js/pages/users.js
   ```
3. Go to **Settings → Pages → Source: main branch → / (root)**
4. Your app will be live at `https://yourusername.github.io/protrack`

## 📁 Data Storage

Data is stored in **localStorage** (browser). To sync across devices:
- Use **Export Backup** (Admin → User Management) to download a `.txt` file
- Use **Import Backup** to restore on another device
- The `.txt` file is plain JSON – you can commit it to your repo as a backup

## 🔐 Default Accounts

| Username | Password | Role |
|----------|----------|------|
| admin | admin123 | Administrator |
| user | user123 | Member |
| guest | guest | Guest (read-only) |

## ✅ Features

- **Dashboard** – KPIs, project status donut, budget utilization, recent activity
- **Project List** – Grid/table view, filter by status/priority/category
- **Project Tracker** – Per-project progress, budget, timeline, team at a glance
- **Gantt Chart** – Interactive visual timeline for all projects + tasks
- **Project Cost** – Budget vs actual tracking, cost logging by category
- **Reports** – Overview, budget, progress, timeline reports + export to .txt
- **Milestones** – Track key deliverables per project
- **Task Board** – Kanban board (Todo → In Progress → Review → Done)
- **Team Members** – Skills, assignments, department management
- **User Management** – Role-based access (Admin only), import/export, reset
- **Access Control** – Admin / User / Guest roles with permission enforcement
- **Mobile Responsive** – Works on phone and desktop
- **Global Search** – Search projects and tasks from header
- **Notifications** – In-app notification system

## 📱 Responsive Design

- **Mobile**: Collapsible sidebar with overlay
- **Tablet**: Adaptive grid layouts
- **Desktop**: Full sidebar with collapse toggle
